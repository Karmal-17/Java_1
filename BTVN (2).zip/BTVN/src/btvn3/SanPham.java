/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package btvn3;

/**
 *
 * @author ADMIN
 */
public class SanPham {
    private String maSanPham;
    private String tenSanPham;
    private double giaSanPham;
    private String nhaSanXuat;

    public SanPham() {
    }

    public SanPham(String maSanPham, String tenSanPham, double giaSanPham, String nhaSanXuat) {
        this.maSanPham = maSanPham;
        this.tenSanPham = tenSanPham;
        this.giaSanPham = giaSanPham;
        this.nhaSanXuat = nhaSanXuat;
    }

    public String getMaSanPham() {
        return maSanPham;
    }

    public void setMaSanPham(String maSanPham) {
        this.maSanPham = maSanPham;
    }

    public String getTenSanPham() {
        return tenSanPham;
    }

    public void setTenSanPham(String tenSanPham) {
        this.tenSanPham = tenSanPham;
    }

    public double getGiaSanPham() {
        return giaSanPham;
    }

    public void setGiaSanPham(double giaSanPham) {
        this.giaSanPham = giaSanPham;
    }

    public String getNhaSanXuat() {
        return nhaSanXuat;
    }

    public void setNhaSanXuat(String nhaSanXuat) {
        this.nhaSanXuat = nhaSanXuat;
    }
    public void inThongTin(){
        System.out.println("ID San Pham: " + this.maSanPham);
        System.out.println("Ten San Pham: " + this.tenSanPham
        + "\nGia Cua San Pham: "  + this.giaSanPham
        + "\nNha San Xuat: " + this.nhaSanXuat);
    }
}
