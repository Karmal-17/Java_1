/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package btvn3;

import java.util.Scanner;

/**
 *
 * @author ADMIN
 */
public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        SanPhamService sanPhamService = new SanPhamService();
        int luaChon;
        do {            
            System.out.println("+--------------------- Menu --------------------------+");
            System.out.println("1. Nhap Thong Tin San Pham.");
            System.out.println("2. In Thong Tin San Pham.");
            System.out.println("3. In Thong Tin Nhung San Pham Co Gia Lon Hon 200000");
            System.out.println("4. Thoat.");
            System.out.println("+------------------------------------------------------+");
            System.out.println("Vui Long Chon So Ban Muon: ");
            luaChon = Integer.valueOf(sc.nextLine());
            switch (luaChon) {
                case 1:
                    sanPhamService.nhapDL();
                    break;
                case 2: 
                    sanPhamService.xuatDL();
                    break;
                case 3: 
                    sanPhamService.timSanPham();
                    break;
                case 4: 
                    System.out.println("Thoat Chuong Trinh Tinh.");
                    System.out.println("Cam On Ban Da Su Dung Chuong Trinh Tinh.");
                    break;
                default:
                    System.out.println("Ban Da Lua Chon Sai So !"
                            + "\n Vui long Chon Lai So Nhe.");
            }
       } while (luaChon != 4);
    }
}
