/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package btvn3;

import java.util.ArrayList;
import java.util.Scanner;
import javax.xml.transform.SourceLocator;

/**
 *
 * @author ADMIN
 */
public class SanPhamService {

    ArrayList<SanPham> sanPhamList = new ArrayList<>();
    Scanner sc = new Scanner(System.in);

    public void nhapDL() {
        System.out.println("Nhap Thong Tin Cua San Pham: ");
        System.out.println("Vui long Nhap ID Cua San Pham: ");
        String id = sc.nextLine();
        System.out.println("Vui Long Nhap Ten Cua San Pham: ");
        String ten = sc.nextLine();
        System.out.println("Vui Long Nhap Gia Cua San Pham: ");
        double gia = Double.valueOf(sc.nextLine());
        System.out.println("Vui long Nhap Nha San Xuat Cua San Pham: ");
        String nhaSX = sc.nextLine();
        SanPham sanPham = new SanPham(nhaSX, ten, gia, nhaSX);
        sanPhamList.add(sanPham);
        System.out.println("Them Thong Tin Thanh Cong.");
    }

    public void xuatDL() {
        System.out.println("Xuat Thong Tin San Pham.");
        if (!sanPhamList.isEmpty()) {
            for (SanPham sanPham : sanPhamList) {
                sanPham.inThongTin();
            }
        } else {
            System.out.println("Do Ban Chua Nhap Du Lieu Vao Bang."
                    + "\nVui Long Chon Lai So 1 De Nhap Thong Tin San Pham Nhe.");
        }
    }

    public void timSanPham() {
        System.out.println("Hien Thi Thong Tin San Phan Co Muc Gia Lon hon 200000.");
        if (!sanPhamList.isEmpty()) {
            for (SanPham sanPham : sanPhamList) {
                if (sanPham.getGiaSanPham() < 200000) {
                    sanPham.inThongTin();
                } else {
                    System.out.println("Chua Co Mot San Pham nao Co Gia Loan Hon 200000.");
                    break;
                }
            }
            System.out.println("In Thong Tin Thanh Cong"
                    + "\n Nhung San Pham Co Gia Lon Hon 200000");
        } else {
            System.out.println("Do Ban Chua Nhap Du Lieu Vao Bang."
                    + "\n Vui Long Long Chon Muc 1 De Nhap Du Lieu Vao Bang.");
        }
    }
}
