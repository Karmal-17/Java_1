/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package btvn;

/**
 *
 * @author ADMIN
 */
public class Meo extends DongVat{
    private String tiengKeuDongVat;

    public Meo() {
    }

    public Meo(String tiengKeuDongVat) {
        this.tiengKeuDongVat = tiengKeuDongVat;
    }

    public Meo(String tiengKeuDongVat, String maDongVat, String tenDongVat, int canNang, String noiSong) {
        super(maDongVat, tenDongVat, canNang, noiSong);
        this.tiengKeuDongVat = tiengKeuDongVat;
    }

    public String getTiengKeuDongVat() {
        return tiengKeuDongVat;
    }

    public void setTiengKeuDongVat(String tiengKeuDongVat) {
        this.tiengKeuDongVat = tiengKeuDongVat;
    }

    @Override
    public void inThongTin() {
        super.inThongTin(); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/OverriddenMethodBody
    }

    @Override
    public void setNoiSong(String noiSong) {
        super.setNoiSong(noiSong); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/OverriddenMethodBody
    }

    @Override
    public String getNoiSong() {
        return super.getNoiSong(); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/OverriddenMethodBody
    }

    @Override
    public void setCanNang(int canNang) {
        super.setCanNang(canNang); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/OverriddenMethodBody
    }

    @Override
    public int getCanNang() {
        return super.getCanNang(); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/OverriddenMethodBody
    }

    @Override
    public void setTenDongVat(String tenDongVat) {
        super.setTenDongVat(tenDongVat); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/OverriddenMethodBody
    }

    @Override
    public String getTenDongVat() {
        return super.getTenDongVat(); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/OverriddenMethodBody
    }

    @Override
    public void setMaDongVat(String maDongVat) {
        super.setMaDongVat(maDongVat); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/OverriddenMethodBody
    }

    @Override
    public String getMaDongVat() {
        return super.getMaDongVat(); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/OverriddenMethodBody
    }

    
}
