/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package btvn;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author ADMIN
 */
public class main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int luaChon;
        Scanner sc = new Scanner(System.in);
        DongVatService dongVatService = new DongVatService();
        do {            
            System.out.println("+------------ Menu ----------------+");
            System.out.println("1. Nhap Thong Tin Dong vat.");
            System.out.println("2. Xuat Thong Tin Dong vat.");
            System.out.println("3. Tim Kiem Can Nang Toi Thieu.");
            System.out.println("4. Thoat.");
            System.out.println("5. Dong Vat Meo.");
            System.out.println("+-----------------------------------+");
            System.out.println("Vui Long Chon So Ban Muon: ");
            luaChon = Integer.valueOf(sc.nextLine());
            switch (luaChon) {
                case 1:
                    dongVatService.nhapDuLieu();
                    break;
                case 2: 
                    dongVatService.xuatDuLieu();
                    break;
                case 3:
                    dongVatService.timKiemCanNang();
                    break;
                case 4: 
                    System.out.println("Thoat Chuong Trinh Dong Vat.");
                    System.out.println("Cam On Ban Da Su Dung Chuong Trinh Dong Vat.");
                    break;
                case 5:
                    
                    break;
                default:
                    System.out.println("Ban Da Chon Sai So Roi!"
                            + "Vui Long Chon Sai So Nhe.");
            }
        } while (luaChon != 4);
    }
    
}
