/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package btvn;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author ADMIN
 */
public class DongVatService {
    ArrayList<DongVat> dongVatList = new ArrayList<>();
    Scanner sc = new Scanner(System.in);
    public void nhapDuLieu(){
        System.out.println("Nhap Thong Tin Dong Vat: ");
        System.out.println("Vui Long Nhap ID Cua Dong Vat: ");
        String idDongVat = sc.nextLine();
        System.out.println("Vui Long Nhap Ten Cua Dong Vat: ");
        String tenDongVat = sc.nextLine();
        System.out.println("Vui Long Nhap Can Nang Cua Dong Vat: ");
        int canNang = Integer.valueOf(sc.nextLine());
        System.out.println("Vui Long Nhap Noi Song Cua Dong Vat: ");
        String noiSong = sc.nextLine();
        DongVat dongVat = new DongVat(idDongVat, tenDongVat, canNang, noiSong);
        dongVatList.add(dongVat);
        System.out.println("Them Thong Tin Dong Vat Co ID: " + idDongVat
                + " Thanh Cong.");
    }
    public void xuatDuLieu(){
        System.out.println("Xuat Thong Tin Cua Dong Vat: ");
        for (DongVat dongVat : dongVatList) {
            dongVat.inThongTin();
        }
    }
    public void timKiemCanNang(){
        System.out.println("Tim Kiem Can Nang Toi Thieu.");
        System.out.println("Vui Long Nhap Can Nang Toi Thieu: ");
        int canNang = Integer.valueOf(sc.nextLine());
        for (DongVat dongVat : dongVatList) {
            if(dongVat.getCanNang() > canNang){
                dongVat.inThongTin();
            }
        }
    }
    public void Meo(){
        Meo Meo = new Meo("Meo Meo Meo", "123", "Con Cho", 23, "O Nha");
        System.out.println("Tieng Keu: " + Meo.getTiengKeuDongVat());
        System.out.println("ID Dong Vat: " + Meo.getMaDongVat());
        System.out.println("Ten Dong Vat Meo: " + Meo.getTenDongVat());
        System.out.println("Can Nang Cua Meo: " + Meo.getCanNang());
        System.out.println("Noi Song Cua Dong Vat Meo: " + Meo.getNoiSong());
        
    }
}
