/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package btvn6;

/**
 *
 * @author ADMIN
 */
public class Xehoi {
    private String maXe;
    private String tenXe;
    private double giaXe;
    private String hangSX;
    private int namSX;
    private String loaiXe;
    private String bienSoXe;
    private String tenChuXe;
    private String sdt;
    private String diaChi;

    public Xehoi() {
    }

    public Xehoi(String maXe, String tenXe, double giaXe, String hangSX, int namSX, String loaiXe, String bienSoXe, String tenChuXe, String sdt, String diaChi) {
        this.maXe = maXe;
        this.tenXe = tenXe;
        this.giaXe = giaXe;
        this.hangSX = hangSX;
        this.namSX = namSX;
        this.loaiXe = loaiXe;
        this.bienSoXe = bienSoXe;
        this.tenChuXe = tenChuXe;
        this.sdt = sdt;
        this.diaChi = diaChi;
    }

    

    public String getMaXe() {
        return maXe;
    }

    public void setMaXe(String maXe) {
        this.maXe = maXe;
    }

    public String getTenXe() {
        return tenXe;
    }

    public void setTenXe(String tenXe) {
        this.tenXe = tenXe;
    }

    public double getGiaXe() {
        return giaXe;
    }

    public void setGiaXe(double giaXe) {
        this.giaXe = giaXe;
    }

    public String getHangSX() {
        return hangSX;
    }

    public void setHangSX(String hangSX) {
        this.hangSX = hangSX;
    }

    public int getNamSX() {
        return namSX;
    }

    public void setNamSX(int namSX) {
        this.namSX = namSX;
    }

    public String getLoaiXe() {
        return loaiXe;
    }

    public void setLoaiXe(String loaiXe) {
        this.loaiXe = loaiXe;
    }

    public String getBienSoXe() {
        return bienSoXe;
    }

    public void setBienSoXe(String bienSoXe) {
        this.bienSoXe = bienSoXe;
    }

    public String getTenChuXe() {
        return tenChuXe;
    }

    public void setTenChuXe(String tenChuXe) {
        this.tenChuXe = tenChuXe;
    }

    public String getSdt() {
        return sdt;
    }

    public void setSdt(String sdt) {
        this.sdt = sdt;
    }

    public String getDiaChi() {
        return diaChi;
    }

    public void setDiaChi(String diaChi) {
        this.diaChi = diaChi;
    }
    
    public void inThongTin(){
        System.out.println("ID Cua Xe Hoi: " + this.maXe);
        System.out.println("Ten Cua Xe Hoi: " + this.tenXe);
        System.out.println("Gia Cua Xe Hoi: " + this.giaXe);
        System.out.println("Hang San Xuat Cua Xe Hoi: " + this.hangSX);
        System.out.println("Nam San Xuat Cua Xe Hoi: " + this.namSX);
        System.out.println("Loai Xe Hoi: " + this.loaiXe);
        System.out.println("Bien So Xe Hoi: " + this.bienSoXe);
        System.out.println("Chu So Huu Xe: " + this.tenChuXe);
        System.out.println("So Dien Thoai Chu Xe: " + this.sdt);
        System.out.println("Dia Chi Nha Chu Xe: " + this.diaChi);
    }
}
