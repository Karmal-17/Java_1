/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package btvn6;

import java.util.Scanner;

/**
 *
 * @author ADMIN
 */
public class Main {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        XehoiService xeHoiService = new XehoiService();
        int luaChon;
        try {
            do {
                System.out.println("+------------------------ Menu ----------------------+");
                System.out.println("1. Nhap Thong Tin Xe Hoi.");
                System.out.println("2. Hien Thi Thong Tin Xe Hoi.");
                System.out.println("3. Hien Thi Thong Tin Xe Hoi Voi Dieu Kien.");
                System.out.println("4. Hien Thi Thong Tin Xe Hoi Tu Nam 2020 Tro Di");
                System.out.println("5. Sap Xep Thong Tin Xe Hoi Giam Dan Theo Gia C1.");
                System.out.println("6. Sap Xep Thong Tin Xe Hoi Giam Dan Theo Gia C2.");
                System.out.println("0. Thoat.");
                System.out.println("+--------------------------------------------------------+");
                System.out.println("Vui Long Chon So Ban Muon: ");
                luaChon = Integer.valueOf(sc.nextLine());
                switch (luaChon) {
                    case 1:
                        xeHoiService.nhapDL();
                        break;
                    case 2:
                        xeHoiService.xuatDL();
                        break;
                    case 3:
                        xeHoiService.timxe();
                        break;
                    case 4:
                        xeHoiService.locNamXe();
                        break;
                    case 5:
                        xeHoiService.sapXepgiamDan();
                        break;
                    case 6:
                        xeHoiService.sapXepgiamDan1();
                        break;
                    case 0:
                        System.out.println("Thoat Chuong Trinh Tinh.");
                        System.out.println("Cam On Ban Da Su Dung Trang Tinh.");
                        break;
                    default:
                        System.out.println("Ban Da Chon Sai So Roi!");
                        System.out.println("Vui Long Chon Lai So Ban Muon Nhe.");
                }
            } while (luaChon != 0);
        } catch (Exception e) {
        }

    }
}
