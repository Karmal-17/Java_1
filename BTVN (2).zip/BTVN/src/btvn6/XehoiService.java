/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package btvn6;

import com.sun.source.tree.BreakTree;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Scanner;

/**
 *
 * @author ADMIN
 */
public class XehoiService {

    ArrayList<Xehoi> xeHoiList = new ArrayList<>();
    Scanner sc = new Scanner(System.in);

    public void nhapDL() {
        try {
            System.out.println("Nhap Du Lieu Xe Hoi.");
            String id;
            while (true) {
                System.out.println("Vui Long Nhap ID Cua Xe: ");
                id = sc.nextLine();
                String partenID = "[a-z]{2}-[0-9]{3}";
                if (id.matches(partenID)) {
                    System.out.println("Ban Da Nhap Dung Ma Xe Roi Day.");
                    break;
                } else {
                    System.out.println("Ban Da Nhap Sai Ma Xe Roi!");
                    System.out.println("Vui Long Nhap Lai Ma Xe Hoi Di Nhe.");
                }
            }
            System.out.println("Vui Long Nhap Ten Cua Xe: ");
            String tenXe = sc.nextLine();
            double giaXe;
            while (true) {
                System.out.println("Vui long Nhap Gia Cua Xe: ");
                giaXe = Double.valueOf(sc.nextLine());
                if (giaXe >= 10000) {
                    System.out.println("Gia Xe Hoi Ban Vua Nhap Be Hon Hoac Bang 10000");
                    System.out.println("Vui long Nhap Lai Gia Cua Xe Di");
                } else {
                    System.out.println("Ban Da Nhap Dung Gia Cua Xe Hoi Roi!");
                    break;
                }
            }
            System.out.println("Vui Long Hang San Xuat Xe: ");
            String hangSX = sc.nextLine();
            int namSX;
            while (true) {
                System.out.println("Vui long Nhap Nam San Xuat Cua Xe: ");
                namSX = Integer.valueOf(sc.nextLine());
                if (namSX >= 2010 && namSX <= 2025) {
                    System.out.println("Ban Da Nhap Dung Nam San Xuat Roi.");
                    break;
                } else if (namSX < 2010) {
                    System.out.println("Do Nam San Xuat Ban Vua Nhap Be Hon Nam 2010.");
                    System.out.println("La Xe Cu Roi Nen Khong Chap Nhan.");
                } else {
                    System.out.println("Do Ban Vua Nhap Nam San Xuat Lon Hon Nam 2025.");
                    System.out.println("Nen Xe Do Chua Duoc San Xuat.");
                }
            }
            System.out.println("Vui long Nhap Loai Xe Hoi: ");
            String loaiXe = sc.nextLine();
            String bienSoXe;
            while (true) {
                System.out.println("Vui Long Nhap Bien So Xe: ");
                bienSoXe = sc.nextLine();
                String partenBIENSO = "[0-9]{2}[a-z]{1}-[0-9]{5}";
                if (bienSoXe.matches(partenBIENSO)) {
                    System.out.println("Ban Da Nhap Dung Bien So Xe.");
                    break;
                } else {
                    System.out.println("Ban Da Nhap Sai Bien So Xe Roi!");
                }
            }
            System.out.println("Vui Long Nhap Ten Chu Xe: ");
            String tenChuXe = sc.nextLine();
            String sdt;
            while (true) {
                System.out.println("Vui Long Nhap So Dien Thoai Cua Chu Xe: ");
                sdt = sc.nextLine();
                String partenSDT = "0[0-9]{9}";
                if (sdt.matches(partenSDT)) {
                    System.out.println("Ban Da Nhap Dung So Dien Thoai Roi Day.");
                    break;
                } else {
                    System.out.println("Ban Da Nhap Sai So Dien Thoai Roi Day!");
                    System.out.println("Nhap Lai Di Nhe.");
                }
            }
            System.out.println("Vui long Nhap Dia Chi Cua Chu So Huu Xe: ");
            String diaChi = sc.nextLine();
        } catch (Exception e) {
        }

    }

    public void xuatDL() {
        System.out.println("Xuat Thong Tin Xe Hoi.");
        if (!xeHoiList.isEmpty()) {
            for (Xehoi xehoi : xeHoiList) {
                xehoi.inThongTin();
            }
            System.out.println("Xuat Thong Tin Thanh Cong.");
        } else {
            System.out.println("Do Ban Chua Them Du Lieu Vao Danh Sach Xe Hoi.");
            System.out.println("Nen Chua Cho Du Lieu Dau Nhe.");
        }

    }

    public void timxe() {
        System.out.println("Hien Thi Thong Tin Xe Co Gia Tri Tren 1 Ty "
                + "\n Thuoc Hang Xe: Audi,Mercedes,BMW");
        if (!xeHoiList.isEmpty()) {
            for (Xehoi xehoi : xeHoiList) {
                if (xehoi.getGiaXe() > 1000000000) {
                    if (xehoi.getHangSX().equalsIgnoreCase("BMW")) {
                        System.out.println("Xe Hoi Co Gia Tri Tren 1 Ty Va Thuoc Hang BWM.");
                        xehoi.inThongTin();
                    } else if (xehoi.getHangSX().equalsIgnoreCase("Mercedes")) {
                        System.out.println("Xe Hoi Co Gia Tri Tren 1 Ty Va Thuoc Hang Meccedes");
                        xehoi.inThongTin();
                    } else if (xehoi.getHangSX().equalsIgnoreCase("Audi")) {
                        System.out.println("Xe Hoi Co Gia Tri Tren 1 Ty Va Thuoc Hang Audi.");
                        xehoi.inThongTin();
                    }
                } else {
                    System.out.println("Chua Tim Thay Thong Tin Xe Hoi Co Gia Tri Tren 1 Ty VND.");
                    break;
                }
            }
        } else {
            System.out.println("Do Chua Tim Thay Du Lieu Trong Danh Sach Xe Hoi.");
            System.out.println("Vui Long Chon Vao Muc So 1 De Them Thong Tin Xe.");
        }
    }

    public void locNamXe() {
        System.out.println("Hien Thi Thong Tin Xe Co Nam San Xuat Tu Nam 2020 Tro Di.");
        if (!xeHoiList.isEmpty()) {
            for (Xehoi xehoi : xeHoiList) {
                if (xehoi.getNamSX() >= 2020) {
                    xehoi.inThongTin();
                } else {
                    System.out.println("Chua Tim Duoc Xe Co Nam San Xuat Tu Nam 2020 Tro Di.");
                    break;
                }
            }
            System.out.println("Xuat Thanh Cong Thong Tin.");
        } else {
            System.out.println("Chua Tim Thay Thong Tin Xe Hoi Noi Tron Danh Sach Xe Hoi.");
            System.out.println("Vui long Chon Muc 1 De Them Thong Tin.");
        }
    }

    public void sapXepgiamDan() {
        Collections.sort(xeHoiList, new Comparator<Xehoi>() {
            @Override
            public int compare(Xehoi o1, Xehoi o2) {
                return Double.compare(o2.getGiaXe(), o1.getGiaXe()); // Sắp xếp giảm dần theo giá
            }
        });
//        Collections.sort(xeHoiList, new Comparator<Xehoi>() {
//            @Override
//            public int compare(Xehoi o1, Xehoi o2) {
//                return Double.compare(o2.getGiaXe(),o1.getGiaXe());
//            }
//        });
        for (Xehoi xehoi : xeHoiList) {
            xehoi.inThongTin();
        }
    }
    public void sapXepgiamDan1() {
        double max = xeHoiList.get(1).getGiaXe();
        for (int i = 1; i < xeHoiList.size(); i++) {
            if(xeHoiList.get(i).getGiaXe() > max){
                max = xeHoiList.get(i).getGiaXe();
            }
        }
        for (int i = 1; i < xeHoiList.size(); i++) {
            if(xeHoiList.get(i).getGiaXe() <= max){
                xeHoiList.get(i).inThongTin();
            }
        }
    }
    public void sapXepgiamDan2(){
        xeHoiList.sort(Comparator.comparing(Xehoi::getGiaXe).reversed());
        for (Xehoi xehoi : xeHoiList) {
            xehoi.inThongTin();
        }
        
    }
}
