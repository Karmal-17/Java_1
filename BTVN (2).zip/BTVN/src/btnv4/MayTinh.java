/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package btnv4;

import java.util.logging.Logger;

/**
 *
 * @author ADMIN
 */
public class MayTinh {
    private String maMT;
    private String tenMT;
    private double giaMT;
    private String hangSX;

    public MayTinh() {
    }

    public MayTinh(String maMT, String tenMT, double giaMT, String hangSX) {
        this.maMT = maMT;
        this.tenMT = tenMT;
        this.giaMT = giaMT;
        this.hangSX = hangSX;
    }

    public String getMaMT() {
        return maMT;
    }

    public void setMaMT(String maMT) {
        this.maMT = maMT;
    }

    public String getTenMT() {
        return tenMT;
    }

    public void setTenMT(String tenMT) {
        this.tenMT = tenMT;
    }

    public double getGiaMT() {
        return giaMT;
    }

    public void setGiaMT(double giaMT) {
        this.giaMT = giaMT;
    }

    public String getHangSX() {
        return hangSX;
    }

    public void setHangSX(String hangSX) {
        this.hangSX = hangSX;
    }
    public void inThongTin(){
        System.out.println("ID Cua May Tinh: " + this.maMT);
        System.out.println("Ten Cua May Tinh: " + this.tenMT);
        System.out.println("Gia Cua May Tinh: " + this.giaMT);
        System.out.println("Hang San Xuat May Tinh: " + this.hangSX);
    }
}
