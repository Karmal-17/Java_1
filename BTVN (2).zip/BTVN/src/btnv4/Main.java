/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package btnv4;

import btvn3.SanPham;
import java.util.Scanner;

/**
 *
 * @author ADMIN
 */
public class Main {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        MayTinhService mayTinhService = new MayTinhService();
        int luaChon;
        do {            
            System.out.println("+-------------- Menu -------------------+");
            System.out.println("1.Nhap Thong Tin.");
            System.out.println("2. Xuat Thong Tin.");
            System.out.println("3. Tim Thong Tin San Pham Lon Hon 15000");
            System.out.println("4. Thoat.");
            System.out.println("+-----------------------------------------+");
            System.out.println("Vui Long Chon So Ban Muon Nhe: ");
            luaChon = Integer.valueOf(sc.nextLine());
            switch (luaChon) {
                case 1:
                    mayTinhService.nhapDL();
                    break;
                case 2: 
                    mayTinhService.xuatDL();
                    break;
                case 3:
                    mayTinhService.timMayTinh();
                    break;
                case 4: 
                    System.out.println("Thoat Chuong Chinh Tinh.");
                    System.out.println("Cam On Ban Da Su Dung Chuong Trinh Tinh.");
                    break;
                default:
                    System.out.println("Ban Da Chon Sai So Roi!");
                    System.out.println("Vu ilong Chon Lai So Nhe.");
            }
        } while (luaChon != 4);
    }

}
