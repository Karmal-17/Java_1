/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package btnv4;

import btvn3.SanPham;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author ADMIN
 */
public class MayTinhService {
    ArrayList<MayTinh> mayTinhList = new ArrayList<>();
    Scanner sc = new Scanner(System.in);
    public void nhapDL(){
        System.out.println("Nhap Thong Tin Cua May Tinh: ");
        System.out.println("Vui long Nhap Ma May Tinh: ");
        String id = sc.nextLine();
        System.out.println("Vui Long Nhap Ten Cua May Tinh: ");
        String ten = sc.nextLine();
        System.out.println("Vui Long Nhap Gia Cua May Tinh: ");
        double gia = Double.valueOf(sc.nextLine());
        System.out.println("Vui Long Nhap Hang San Xuat Cua May Tinh: ");
        String hang = sc.nextLine();
        MayTinh mayTinh = new MayTinh(hang, ten, gia, hang);
        mayTinhList.add(mayTinh);
        System.out.println("Them Tong Tin Thanh Cong.");
    }
    public void xuatDL(){
        System.out.println("Xuat Thong Tin May Tinh.");
        if(!mayTinhList.isEmpty()){
            for (MayTinh mayTinh : mayTinhList) {
                mayTinh.inThongTin();
            }
        } else {
            System.out.println("Do Ban Chua Nhap Thong Tin Nao Vao Danh Sach May Tinh.");
            System.out.println("Vui Long Chon Muc So 1 De Nhap Du Lieu Nhe.");
        }
    }
    public void timMayTinh(){
        int i = 1;
        if(!mayTinhList.isEmpty()){
            for (MayTinh mayTinh : mayTinhList) {
                if(mayTinh.getGiaMT() > 15000){
                    if(mayTinh.getHangSX().equalsIgnoreCase("Dell")){
                        System.out.println("May Tinh Dell Thu " + i ++);
                        mayTinh.inThongTin();
                    } else if(mayTinh.getHangSX().equalsIgnoreCase("Apple")){
                        System.out.println("May Tinh Apple Thu " + i ++);
                        mayTinh.inThongTin();
                    } else {
                        System.out.println("Chua Tim Thay May Tinh Co Gia Lon Han 15000 Thuoc Hang Dell Va Apple.");
                    }
                } else {
                    System.out.println("Chua Tim Thay May Tinh nao Co Gia Lon Hon 15000");
                    break;
                }
            }
        }
    }
}
