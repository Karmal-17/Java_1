/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package btvn1;

import java.util.logging.Logger;

/**
 *
 * @author ADMIN
 */
public class DayChuyen extends TrangSuc{
    private String chatLieu;

    public DayChuyen() {
    }

    public DayChuyen(String chatLieu) {
        this.chatLieu = chatLieu;
    }

    public DayChuyen(String chatLieu, String maTrangSuc, String tenTrangSuc, double giaTrangSuc, String nhaSX) {
        super(maTrangSuc, tenTrangSuc, giaTrangSuc, nhaSX);
        this.chatLieu = chatLieu;
    }

    public String getChatLieu() {
        return chatLieu;
    }

    public void setChatLieu(String chatLieu) {
        this.chatLieu = chatLieu;
    }

    @Override
    public void inThongTin() {
        super.inThongTin(); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/OverriddenMethodBody
    }

    @Override
    public void setNhaSX(String nhaSX) {
        super.setNhaSX(nhaSX); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/OverriddenMethodBody
    }

    @Override
    public String getNhaSX() {
        return super.getNhaSX(); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/OverriddenMethodBody
    }

    @Override
    public void setGiaTrangSuc(double giaTrangSuc) {
        super.setGiaTrangSuc(giaTrangSuc); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/OverriddenMethodBody
    }

    @Override
    public double getGiaTrangSuc() {
        return super.getGiaTrangSuc(); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/OverriddenMethodBody
    }

    @Override
    public void setTenTrangSuc(String tenTrangSuc) {
        super.setTenTrangSuc(tenTrangSuc); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/OverriddenMethodBody
    }

    @Override
    public String getTenTrangSuc() {
        return super.getTenTrangSuc(); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/OverriddenMethodBody
    }

    @Override
    public void setMaTrangSuc(String maTrangSuc) {
        super.setMaTrangSuc(maTrangSuc); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/OverriddenMethodBody
    }

    @Override
    public String getMaTrangSuc() {
        return super.getMaTrangSuc(); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/OverriddenMethodBody
    }

    
    public void intoString() {
          System.out.println("Chat Lieu: " + this.chatLieu + "ID Cua Trang Suc: " + super.getMaTrangSuc() + " Ten Cua Trang Suc: " + super.getTenTrangSuc() + " Gia Cua Trang Suc: " + super.getGiaTrangSuc() + " Nha San Xuat Trang Xuc: " + super.getNhaSX());
   
    }
    
}
