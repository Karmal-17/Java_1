/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package btvn1;

/**
 *
 * @author ADMIN
 */
public class TrangSuc {
    private String maTrangSuc;
    private String tenTrangSuc;
    private double giaTrangSuc;
    private String nhaSX;

    public TrangSuc() {
    }

    public TrangSuc(String maTrangSuc, String tenTrangSuc, double giaTrangSuc, String nhaSX) {
        this.maTrangSuc = maTrangSuc;
        this.tenTrangSuc = tenTrangSuc;
        this.giaTrangSuc = giaTrangSuc;
        this.nhaSX = nhaSX;
    }

    public String getMaTrangSuc() {
        return maTrangSuc;
    }

    public void setMaTrangSuc(String maTrangSuc) {
        this.maTrangSuc = maTrangSuc;
    }

    public String getTenTrangSuc() {
        return tenTrangSuc;
    }

    public void setTenTrangSuc(String tenTrangSuc) {
        this.tenTrangSuc = tenTrangSuc;
    }

    public double getGiaTrangSuc() {
        return giaTrangSuc;
    }

    public void setGiaTrangSuc(double giaTrangSuc) {
        this.giaTrangSuc = giaTrangSuc;
    }

    public String getNhaSX() {
        return nhaSX;
    }

    public void setNhaSX(String nhaSX) {
        this.nhaSX = nhaSX;
    }
    public void inThongTin(){
        System.out.println("ID Cua Trang Suc: " + this.maTrangSuc + " Ten Cua Trang Suc: " + this.tenTrangSuc + " Gia Cua Trang Suc: " + this.giaTrangSuc + " Nha San Xuat Trang Xuc: " + this.nhaSX);
    }
}
