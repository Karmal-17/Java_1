/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package btvn1;

import java.util.Scanner;

/**
 *
 * @author ADMIN
 */
public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        TrangSucService trangSuc = new TrangSucService();
        int luaChon;
        do {            
            System.out.println("+------------------- Menu ------------------------+"
                    + "\n 1. Nhap Du Lieu Trang Suc."
                    + "\n 2. Hien Thi Tong Tin."
                    + "\n 3. Xuat Thong Tin Trang Suc Co Gia Lon Hon 100000."
                    + "\n 4. Thoat."
                    + "\n 5. Day Chuyen."
                    + "\n +-------------------------------------------------------+");
            System.out.println("Vui Long Chon So Ban Muon: ");
            luaChon = Integer.valueOf(sc.nextLine());
            switch (luaChon) {
                case 1:
                    trangSuc.nhapDuLieu();
                    break;
                case 2: 
                    trangSuc.xuatDuLieu();
                    break;
                case 3:
                    trangSuc.hienThiGia();
                    break;
                case 4: 
                    System.out.println("Thoat Chuong Trinh."
                            + "Cam On Ban Da Su Dung Chuong Trinh.");
                    break;
                case 5:
                    trangSuc.dayChuyen();
                    break;
                default:
                    System.out.println("Ban Da Nhap Sai So");
//                    break;
            }
        } while (luaChon != 4);
    }
}
