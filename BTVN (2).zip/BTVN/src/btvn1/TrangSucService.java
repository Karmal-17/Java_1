/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package btvn1;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author ADMIN
 */
public class TrangSucService {
    ArrayList<TrangSuc> trangSucList = new ArrayList<>();
    Scanner sc = new Scanner(System.in);
    public void nhapDuLieu(){
        System.out.println("Nhap Thong Tin Trang Suc: ");
        System.out.println("Vui Long Nhap ID Cua Trang Suc: ");
        String id = sc.nextLine();
        System.out.println("Vui Long Nhap Ten Cua Trang Suc: ");
        String ten = sc.nextLine();
        System.out.println("Vui Long Nhap Gia Cua Trang Suc: ");
        double gia = Double.valueOf(sc.nextLine());
        System.out.println("Vui Long Nhap Nha San Xuat Trang Suc: ");
        String nhaSX = sc.nextLine();
        TrangSuc trangSuc = new TrangSuc(nhaSX, nhaSX, gia, nhaSX);
        trangSucList.add(trangSuc);
        System.out.println("Them Thong Tin Thanh Cong Vao Danh Sach.");
    }
    public void xuatDuLieu(){
        for (TrangSuc trangSuc : trangSucList) {
            trangSuc.inThongTin();
        }      
    }
    public void hienThiGia(){
        
        for (TrangSuc trangSuc : trangSucList) {
            if(trangSuc.getGiaTrangSuc() > 100000){
                trangSuc.inThongTin();
            } else {
                System.out.println("Khong Co Thang Nao Co Gia Lon Hon 100000 Dau Dung Tim.");
                break;
            }
        }
        
    }
    public void dayChuyen(){
        DayChuyen dayChuyen = new DayChuyen("GOLD 9999", "001", "Vang Noi", 123456789, "Bao Nguyen");
        System.out.println("Chat Lieu: " + dayChuyen.getChatLieu());
        System.out.println("ID Cua Trang Suc: " + dayChuyen.getMaTrangSuc());
        System.out.println("Ten Cua Trang Suc: " + dayChuyen.getTenTrangSuc());
        System.out.println("Gia Cua Trang Suc: "  + dayChuyen.getGiaTrangSuc());
        System.out.println("Nha San Xuat: " + dayChuyen.getNhaSX());
    }
    
}
