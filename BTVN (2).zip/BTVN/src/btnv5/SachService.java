/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package btnv5;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author ADMIN
 */
public class SachService {
    ArrayList<Sach> sachList = new ArrayList<>();
    Scanner sc = new Scanner(System.in);
    public  void nhapDL(){
        System.out.println("Nhap Tonh Tin Sach.");
        System.out.println("Vui long Nhap ID Cua Sach: ");
        String id = sc.nextLine();
        System.out.println("Vui long Nhap Ten Cua Sach: ");
        String ten = sc.nextLine();
        System.out.println("Vui Long Nhap So Trang Sach: ");
        int soTrang = Integer.valueOf(sc.nextLine());
        System.out.println("Vui Long Nhap Gia Cua Sach: ");
        double gia = Double.valueOf(sc.nextLine());
        System.out.println("Vui Long Nhap Ten Tac Gia: ");
        String tenTacGia = sc.nextLine();
        Sach sach = new Sach(ten, tenTacGia, soTrang, gia, tenTacGia);
        sachList.add(sach);
        System.out.println("Them Thanh Cong Du Lieu Vao Bang Sach List.");       
    }
    public void xuatDL(){
        System.out.println("Xuat Thong Tin Sach: ");
        if(!sachList.isEmpty()){
            for (Sach sach : sachList) {
                sach.inThongTin();
            }
        } else {
            System.out.println("Do Ban Chua Nhap Du Lieu Sach Vao Ban.");
            System.out.println("Vui Long Chon Muc So 1 De Them Du Lieu Vao Bang.");
        }
    }
    public void timThongTinSach(){
        if(!sachList.isEmpty()){
            for (Sach sach : sachList) {
                if(sach.getGiaSach() > 500000 && sach.getSoTrangSach() > 500){
                    if(sach.getTenTacGia().startsWith("Nguyen")){
                        sach.inThongTin();
                    } else if(sach.getTenTacGia().startsWith("Tran")){
                        sach.inThongTin();
                    } else {
                        sach.inThongTin();
                    }
                } else {
                    System.out.println("Chua Tim Thay Sach Nao Co Gia Lon Hon 500000 Va So Trang Lon Hon 500 Trang.");
                    break;
                }
            }
        } else {
            System.out.println("Chua Tim Thay Thong Tin Sach.");
            System.out.println("Vui Long Chon Muc So 1 De Nhap Du Lieu Sach Nhe.");
        }
    }
}
