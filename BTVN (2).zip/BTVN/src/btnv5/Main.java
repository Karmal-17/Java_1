/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package btnv5;

import java.util.Scanner;

/**
 *
 * @author ADMIN
 */
public class Main {
    public static void main(String[] args) {
        Scanner sc = new  Scanner(System.in);
        int luaChon;
        SachService sachService = new SachService();
        do {            
            System.out.println("+----------- MENU -----------------------+");
            System.out.println("1. Nhap Thong Tin Sach.");
            System.out.println("2. Xuat Thong Tin Sach.");
            System.out.println("3. Hien Thi Sach Theo Yeu Cau.");
            System.out.println("4. Thoat.");
            System.out.println("+----------------------------------------+");
            System.out.println("Vui long Chon So Ban Muon Nhe: ");
            luaChon = Integer.valueOf(sc.nextLine());
            switch (luaChon) {
                case 1:
                    sachService.nhapDL();
                    break;
                case 2:
                    sachService.xuatDL();
                    break;
                case 3: 
                   sachService.timThongTinSach();
                   break;
                case 4:
                    System.out.println("Thoat Chuong Trinh Sach.");
                    System.out.println("Cam On Ban Da Su Dung Truong Trinh Tinh.");
                    break;
                default:
                    System.out.println("Ban Da Chon Sai So Roi Day.");
                    System.out.println("Vu ilong Chon Lai So Di Nhe.");
            }
        } while (luaChon != 4);
    }
}
