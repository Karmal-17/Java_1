/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package btvn2;

/**
 *
 * @author ADMIN
 */
public class MonAn {
    private String ma;
    private String ten;
    private double gia;
    private int trangThai;

    public MonAn() {
    }

    public MonAn(String ma, String ten, double gia, int trangThai) {
        this.ma = ma;
        this.ten = ten;
        this.gia = gia;
        this.trangThai = trangThai;
    }

    public String getMa() {
        return ma;
    }

    public void setMa(String ma) {
        this.ma = ma;
    }

    public String getTen() {
        return ten;
    }

    public void setTen(String ten) {
        this.ten = ten;
    }

    public double getGia() {
        return gia;
    }

    public void setGia(double gia) {
        this.gia = gia;
    }

    public int getTrangThai() {
        return trangThai;
    }

    public void setTrangThai(int trangThai) {
        this.trangThai = trangThai;
    }
    public void inThongTin(){
        System.out.println("ID Mon An: " + this.ma + " Ten Mon An: " + this.ten + " Gia Mon An: " + this.gia + " Trang Thai: " + this.trangThai );
    }
}
