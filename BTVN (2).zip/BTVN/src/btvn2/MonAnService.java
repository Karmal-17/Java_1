/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package btvn2;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Scanner;

/**
 *
 * @author ADMIN
 */
public class MonAnService {
    ArrayList<MonAn> monAnList = new ArrayList<>();
    Scanner sc = new Scanner(System.in);
    public void nhapDuLieu(){
        System.out.println("Nhap Thong Tin Mon An.");
        System.out.println("Vui Long Nhap ID Mon An: ");
        String id = sc.nextLine();
        System.out.println("Vui Long Nhap Ten Mon An: ");
        String ten = sc.nextLine();
        System.out.println("Vui Long Nhap Gia Mon An: ");
        double gia = Double.valueOf(sc.nextLine());
        int trangThai;
        while(true){
            System.out.println("Vui Long Nhap Trang Thai Mon An (Có = 1,Khong = 0): ");
            trangThai = Integer.valueOf(sc.nextLine());
            if(trangThai == 1){
                break;
            } else if(trangThai == 0){
                break;
            } else {
                System.out.println("Nhap Lai Di");
            }
        }
        MonAn monAn = new MonAn(id, ten, gia, trangThai);
        monAnList.add(monAn);
        System.out.println("Them Thong Tin Thanh Cong.");
   }
    public void xuatDuLieu(){
        for (MonAn monAn : monAnList) {
            monAn.inThongTin();
        }
    }
    public void sapXep(){
        monAnList.sort(Comparator.comparing(MonAn::getMa));
        System.out.println("Danh Sach Da Duoc Sap Xep Theo Ma.");    
        
    }
    public void monAnChay(){
        MonAnChay monAnChay = new MonAnChay("GOLD 9999", "001", "VANG NOI", 1234567, 1);
        monAnChay.inThongTinMonAnChay();
    }
    public void tangdan(){
        monAnList.sort(Comparator.comparing(MonAn::getGia));
        for (MonAn monAn : monAnList) {
            monAn.inThongTin();
        }
        Collections.sort(monAnList, new Comparator<MonAn>() {
            @Override
            public int compare(MonAn o1, MonAn o2) {
                return Double.compare(o1.getGia(), o2.getGia());
            }
        });
    }
}
