/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package btvn2;

import java.util.Scanner;

/**
 *
 * @author ADMIN
 */
public class Main {
    public static void main(String[] args) {
        Scanner sc  = new Scanner(System.in);
        MonAnService monAn = new MonAnService();
        int luaChon;
        do {            
            System.out.println("+--------------------- Menu -----------------+");
            System.out.println("1. Nhap Thong Tin.");
            System.out.println("2. Xuat Thong Thong Tin.");
            System.out.println("3. In Thong Tin Theo Yeu Cau.");
            System.out.println("4. Thoat.");
            System.out.println("5. Mon An Chay.");
            System.out.println("+-----------------------------------------------+");
            System.out.println("Vui Long Chon So Ban Muon: ");
            luaChon = Integer.valueOf(sc.nextLine());
            switch (luaChon) {
                case 1:
                    monAn.nhapDuLieu();
                    break;
                case 2:
                    monAn.xuatDuLieu();
                    break;
                case 3:
                    monAn.sapXep();
                    break;
                case 4: 
                    System.out.println("Thoat Chuong Trinh.");
                    System.out.println("Cam On Ban Ban Da Su Dung Chuong Trinh Nhe.");
                    break;
                case 5:
                    monAn.monAnChay();
                    break;
                default:
                    System.out.println("Ban Da Chon Sai So Roi!");
            }
        } while (luaChon != 4);
    }
}
