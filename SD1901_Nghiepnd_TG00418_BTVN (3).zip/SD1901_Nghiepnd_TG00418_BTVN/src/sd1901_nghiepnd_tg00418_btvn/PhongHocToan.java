/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sd1901_nghiepnd_tg00418_btvn;

/**
 *
 * @author ADMIN
 */
public class PhongHocToan extends PhongHoc {
    private int soLopDuocHoc;

    public PhongHocToan() {
    }

    public PhongHocToan(int soLopDuocHoc) {
        this.soLopDuocHoc = soLopDuocHoc;
    }

    public PhongHocToan(int soLopDuocHoc, String id, String tenPhong, String tenToa, float dienTich) {
        super(id, tenPhong, tenToa, dienTich);
        this.soLopDuocHoc = soLopDuocHoc;
    }

    public int getSoLopDuocHoc() {
        return soLopDuocHoc;
    }

    public void setSoLopDuocHoc(int soLopDuocHoc) {
        this.soLopDuocHoc = soLopDuocHoc;
    }

    @Override
    public void setDienTich(float dienTich) {
        super.setDienTich(dienTich); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/OverriddenMethodBody
    }

    @Override
    public float getDienTich() {
        return super.getDienTich(); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/OverriddenMethodBody
    }

    @Override
    public void setTenToa(String tenToa) {
        super.setTenToa(tenToa); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/OverriddenMethodBody
    }

    @Override
    public String getTenToa() {
        return super.getTenToa(); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/OverriddenMethodBody
    }

    @Override
    public void setTenPhong(String tenPhong) {
        super.setTenPhong(tenPhong); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/OverriddenMethodBody
    }

    @Override
    public String getTenPhong() {
        return super.getTenPhong(); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/OverriddenMethodBody
    }

    @Override
    public void setId(String id) {
        super.setId(id); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/OverriddenMethodBody
    }

    @Override
    public String getId() {
        return super.getId(); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/OverriddenMethodBody
    }
    
    
    @Override
    public void inThongTin() {
        super.inThongTin();
        System.out.println("So Lop Duoc Hoc La: " + soLopDuocHoc);// Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/OverriddenMethodBody
    }

    
    
}
