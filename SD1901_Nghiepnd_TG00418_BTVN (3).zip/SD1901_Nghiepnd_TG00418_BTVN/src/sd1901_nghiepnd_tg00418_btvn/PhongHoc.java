/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sd1901_nghiepnd_tg00418_btvn;

/**
 *
 * @author ADMIN
 */
public class PhongHoc {
    private String id;
    private String tenPhong;
    private String tenToa;
    private float dienTich;

    public PhongHoc() {
    }

    public PhongHoc(String id, String tenPhong, String tenToa, float dienTich) {
        this.id = id;
        this.tenPhong = tenPhong;
        this.tenToa = tenToa;
        this.dienTich = dienTich;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTenPhong() {
        return tenPhong;
    }

    public void setTenPhong(String tenPhong) {
        this.tenPhong = tenPhong;
    }

    public String getTenToa() {
        return tenToa;
    }

    public void setTenToa(String tenToa) {
        this.tenToa = tenToa;
    }

    public float getDienTich() {
        return dienTich;
    }
    public void setDienTich(float dienTich) {
        this.dienTich = dienTich;
    }

    public void inThongTin() {
        System.out.println("ID: " + id + ", Tên phòng: " + tenPhong + ", Tòa: " + tenToa + ", Diện tích: " + dienTich);
    }


}
