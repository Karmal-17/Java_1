/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sd1901_nghiepnd_tg00418_btvn;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author ADMIN
 */
public class PhongHocService {

    Scanner sc = new Scanner(System.in);
    ArrayList<PhongHoc> phongHocList = new ArrayList<>();
    PhongHoc PH = new PhongHoc();

    public void NhapDL() {
        System.out.println("1. Vui Long Nhap Het Cac Thong Tin.");
        System.out.println("Vui Long Nhap Ma So: ");
        String id = sc.nextLine();
        while (true) {
            System.out.println("Vui Long Nhap Ten Phong Hoc: ");
            String tenPhongHoc = sc.nextLine();
            if (tenPhongHoc.startsWith("PH")) {
                break;
            } else {
                System.out.println("Ten Phong Phai Bat Dau Bang Chu PH.");
            }
        }
        System.out.println("Vui Long Nhap Ten Toa Hoc: ");
        String tenToa = sc.nextLine();
        System.out.println("Vui Long Nhap Dien Tich: ");
        float dienTich = Float.valueOf(sc.nextLine());
        phongHocList.add(PH);
        System.out.println("Them Du Lieu Thanh Cong.");
    }

    public void XuatDL() {
        System.out.println("2. Hien Thi Thong Tin.");

        if (phongHocList.size() < 0) {
            for (PhongHoc phongHoc : phongHocList) {
                System.out.println(phongHocList);
            }
            System.out.println("Hien Thi Thanh Cong Thong Tin Phong Hoc.");
        } else {
            System.out.println("Do Ban Chua Nhap Thong Tin Vao Danh Sach Phoong Hoc."
                    + "Nen Chua Co Du Lieu Nhe.");
        }

    }

    public void TimDL() {
        System.out.println("3. Tim Thong Tin Phong Hoc Theo Dien Tich.");
        System.out.println("Vui Long Nhap Dien Tich (Min): ");
        float dTmin = Float.valueOf(sc.nextLine());
        System.out.println("Vui Long Nhap Dien Tich (Max): ");
        float dTmax = Float.valueOf(sc.nextLine());
        if (phongHocList.size() >= 0) {
            System.out.println("Do Ban Chua Nhap Thong Tin Vao Danh Sach Phong Hoc."
                    + "Vui Long Them Ngay Thong Tin De Tiep Tuc.");
        } else {
            for (PhongHoc phongHoc : phongHocList) {
                if (phongHoc.getDienTich() >= dTmin && phongHoc.getDienTich() <= dTmax) {
                    System.out.println(phongHocList);
                } else {
                    System.out.println("Chua Tim Duoc Phong Hoc Nao Co Dien Tich (Min = " + dTmin + " ,Max = " + dTmax + " ) Nhe.");
                }
            }
        }
    }

    public void hienThiDTMAX() {
        float max = phongHocList.get(1).getDienTich();
        int viTriMax = 1;
        for (int i = 1; i < phongHocList.size(); i++) {
            if (max < phongHocList.get(i).getDienTich()) {
                max = phongHocList.get(i).getDienTich();
                viTriMax = i;
            }
        }
        System.out.println("Phong Co Dien Tich Max: " + max);
        for (PhongHoc phongHoc : phongHocList) {
            if (phongHoc.getDienTich() == max) {
                phongHoc.inThongTin();
            }
        }
    }

    public void hienThiDTTB() {
        float tong = 0;
        for (int i = 1; i < phongHocList.size(); i++) {
            tong = tong + phongHocList.get(i).getDienTich();
        }
        float trungBinh = tong / phongHocList.size();
        System.out.println("Trung Binh: " + trungBinh);
    }

    public void hienThiTimID() {
        System.out.println("Vui Long Nhap ID: ");
        String ID = sc.nextLine();

        for (PhongHoc phongHoc : phongHocList) {
            if (phongHoc.getId().equalsIgnoreCase(ID)) {
                phongHoc.inThongTin();
            }
        }
    }

    public void phongHocToan() {
//        Nhập Dữ Liệu
        PhongHocToan phHocToan = new PhongHocToan(101, "T302", "TOAN", "T1", 122);
//        Xuất Dữ Liệu

    }
}
