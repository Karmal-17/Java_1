/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package sd1901_nghiepnd_tg00418_btvn;

import com.sun.jdi.connect.LaunchingConnector;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author ADMIN
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner sc = new  Scanner(System.in);
//        ArrayList<PhongHoc> phongHocList = new ArrayList<>();
        PhongHocService phongHoc = new PhongHocService();
        while (true) {            
            System.out.println("+------------ Menu --------------+");
            System.out.println("1. Nhap Thong Tin.");
            System.out.println("2. Xuat Thong Tin.");
            System.out.println("3. Tim Kiem Theo Dien Tich.");
            System.out.println("4. Hien Thi Max.");
            System.out.println("5. Tim Trung Binh.");
            System.out.println("6. Tim ID.");
            System.out.println("0. Thoat.");
            int LuaChon = Integer.valueOf(sc.nextLine());
            if(LuaChon == 0){
                System.out.println("Thoat Chuong Trinh."
                        + "cam On Ban Da Su Dung Chuong Trinh.");
                break;
            }
            switch (LuaChon) {
                case 1:{
                    phongHoc.NhapDL();
                  break;
                }
                case 2: {
                    phongHoc.XuatDL();
                    break;
                }
                
                case 3: {
                    phongHoc.TimDL();                   
                    break;
                }
                case 4: {
                    phongHoc.hienThiDTMAX();
                    break;
                }
                case 5: {
                    phongHoc.hienThiDTTB();
                    break;
                }
                case 6: {
                    phongHoc.hienThiTimID();
                    break;
                }
                default:
                    System.out.println("Ban Da Chon Sai So Roi!!!"
                            + "Vui Long Chon Lai So Nhe.");
            }
        }
        return;
    }
    
}
