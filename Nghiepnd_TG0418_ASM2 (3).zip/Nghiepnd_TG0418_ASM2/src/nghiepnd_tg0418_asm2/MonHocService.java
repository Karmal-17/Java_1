/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package nghiepnd_tg0418_asm2;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author ADMIN
 */
public class MonHocService {

    ArrayList<MonHoc> monHocList = new ArrayList<>();
    Scanner sc = new Scanner(System.in);

    public void NhapDL() {
        while (true) {
            System.out.println("1. Nhap Thong Tin Mon Hoc.");
            System.out.println("Vui Long Nhap Ma Mon Hoc: ");
            String maMon = sc.nextLine();
            System.out.println("Vui Long Nhap Ten Mon Hoc: ");
            String tenMon = sc.nextLine();

            System.out.println("Vui Long Nhap So Tin Chi: ");
            int soTinChi = Integer.valueOf(sc.nextLine());

            MonHoc mH = new MonHoc(maMon, tenMon, soTinChi);
            monHocList.add(mH);

            if (soTinChi > 0) {
                System.out.println("Da Them Du Lieu Thanh Cong.");
                break;
            } else {
                System.out.println("So Tin Chi Cua Ban Phai Lon Hon 0.");
            }

        }
    }

    public void NhapDL1() {
        System.out.println("1. Nhap Thong Tin Mon Hoc.");
        System.out.println("Vui Long Nhap Ma Mon Hoc: ");
        String maMon = sc.nextLine();
        System.out.println("Vui Long Nhap Ten Mon Hoc: ");
        String tenMon = sc.nextLine();
        int soTinChi;
        while (true) {
            System.out.println("Vui Long Nhap So Tin Chi: ");
            soTinChi = Integer.valueOf(sc.nextLine());
            if (soTinChi > 0) {
                break;
            } else {
                System.out.println("Nhap Lai Di.");
            }
        }

        MonHoc mH = new MonHoc(maMon, tenMon, soTinChi);
        monHocList.add(mH);
    }

    public void XuatDL() {
        System.out.println("Xuat Thong Tin Mon Hoc.");
        for (MonHoc monHoc : monHocList) {
            monHoc.inThongTin();
        }
        System.out.println("Xuat Thanh Cong Thong Tin Mon Hoc.");
    }

    public void NhapMonHocOnline() {
        System.out.println("Thong Tin Mon Hoc Online.");
        MonHocOnline mhOnline = new MonHocOnline("www.linkmeet", "001", "Toan Cao Cap.", 15);
        System.out.println("Link Mon Hoc Online: " + mhOnline.getLinkMeet());
        System.out.println("Ma Mon Hoc Online: " + mhOnline.getMaMon());
        System.out.println("Ten Mon Hoc Online: " + mhOnline.getTenMon());
        System.out.println("So Tin Chi Mon Hoc Online: " + mhOnline.getSoTinChi());
    }
}
