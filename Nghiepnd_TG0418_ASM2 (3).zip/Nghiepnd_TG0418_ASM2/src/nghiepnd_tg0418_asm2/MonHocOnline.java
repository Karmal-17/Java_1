/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package nghiepnd_tg0418_asm2;

/**
 *
 * @author ADMIN
 */
public class MonHocOnline extends MonHoc {
    private String linkMeet;

    public MonHocOnline() {
    }

    public MonHocOnline(String linkMeet) {
        this.linkMeet = linkMeet;
    }

    public MonHocOnline(String linkMeet, String maMon, String tenMon, int soTinChi) {
        super(maMon, tenMon, soTinChi);
        this.linkMeet = linkMeet;
    }

    public String getLinkMeet() {
        return linkMeet;
    }

    public void setLinkMeet(String linkMeet) {
        this.linkMeet = linkMeet;
    }

    @Override
    public void inThongTin() {
        super.inThongTin(); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/OverriddenMethodBody
    }

    @Override
    public void setSoTinChi(int soTinChi) {
        super.setSoTinChi(soTinChi); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/OverriddenMethodBody
    }

    @Override
    public int getSoTinChi() {
        return super.getSoTinChi(); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/OverriddenMethodBody
    }

    @Override
    public void setTenMon(String tenMon) {
        super.setTenMon(tenMon); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/OverriddenMethodBody
    }

    @Override
    public String getTenMon() {
        return super.getTenMon(); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/OverriddenMethodBody
    }

    @Override
    public void setMaMon(String maMon) {
        super.setMaMon(maMon); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/OverriddenMethodBody
    }

    @Override
    public String getMaMon() {
        return super.getMaMon(); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/OverriddenMethodBody
    }
    
}
