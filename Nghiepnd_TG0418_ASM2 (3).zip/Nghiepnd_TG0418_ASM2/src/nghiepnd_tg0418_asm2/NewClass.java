/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package nghiepnd_tg0418_asm2;

/**
 *
 * @author ADMIN
 */
public class NewClass {
    public static void main(String[] args) {
        System.out.println("Vui Lòng Nhập Họ Tên Của Bạn");
    }
}
