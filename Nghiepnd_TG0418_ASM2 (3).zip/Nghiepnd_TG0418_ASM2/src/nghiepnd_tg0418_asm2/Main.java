/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package nghiepnd_tg0418_asm2;

import java.util.Scanner;

/**
 *
 * @author ADMIN
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner sc = new Scanner(System.in);
        MonHocService mHocService = new MonHocService();
        int LuaChon;
        do {
            System.out.println("+--------------- Menu --------------------+");
            System.out.println("1. Nhap Thon Tin Doi Tuong.");
            System.out.println("2. Hien Thi Danh Sach Doi Tuong.");
            System.out.println("3. Ke Thua.");
            System.out.println("4. Thoat.");
            System.out.println("+------------------------------------------+");
            System.out.println("Vui Long Chon So Ban Muon: ");
            LuaChon = Integer.parseInt(sc.nextLine());
            switch (LuaChon) {
                case 1: {
                    mHocService.NhapDL1();
                    break;
                }
                case 2: {
                    mHocService.XuatDL();
                    break;
                }
                case 3: {
                    mHocService.NhapMonHocOnline();
                    break;
                }
                case 4: {
                    System.out.println("Thoat Chuong Trinh Lop Hoc.");
                    System.out.println("Cam On Ban Da Su Dung Chuong Trinh.");
                    break;
                }
                default:
                    System.out.println("Ban Da Chon Sai So Roi!.");
                    System.out.println("Vui Long Chon Lai So Nhe.");
            }
        } while (LuaChon != 4);
    }

}
