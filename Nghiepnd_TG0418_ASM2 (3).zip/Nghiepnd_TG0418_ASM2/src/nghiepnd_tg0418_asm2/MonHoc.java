/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package nghiepnd_tg0418_asm2;

/**
 *
 * @author ADMIN
 */
public class MonHoc {
    private String maMon;
    private String tenMon;
    private int soTinChi;

    public MonHoc() {
    }

    public MonHoc(String maMon, String tenMon, int soTinChi) {
        this.maMon = maMon;
        this.tenMon = tenMon;
        this.soTinChi = soTinChi;
    }

    public String getMaMon() {
        return maMon;
    }

    public void setMaMon(String maMon) {
        this.maMon = maMon;
    }

    public String getTenMon() {
        return tenMon;
    }

    public void setTenMon(String tenMon) {
        this.tenMon = tenMon;
    }

    public int getSoTinChi() {
        return soTinChi;
    }

    public void setSoTinChi(int soTinChi) {
        this.soTinChi = soTinChi;
    }
    
    public void inThongTin(){
        System.out.println("Ma Mon: " + this.maMon + " Ten Mon: " + this.tenMon + " So Tin Chi: " + this.soTinChi);
    }
}
