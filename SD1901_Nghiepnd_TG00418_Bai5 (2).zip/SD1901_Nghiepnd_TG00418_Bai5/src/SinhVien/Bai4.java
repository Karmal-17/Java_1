/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package SinhVien;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

/**
 *
 * @author ADMIN
 */
public class Bai4 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Map<String, String> taoMapsv = new HashMap<>();
        taoMapsv.put("PC08044", "Ly Chi Thanh");
        taoMapsv.put("PC08122", "Nguyen Thanh Dat");
        taoMapsv.put("PC08503", "Nguyen Nhat Tien");
        taoMapsv.put("PC09014", "Nguyen Van Vi");
        int LuaChon;
        do {
            System.out.println("+-------- Menu --------+");
            System.out.println("1. Truy Xuat Thong Tin Sinh Vien Da Co Trong He Thong Du Tren Ma So.");
            System.out.println("2. Truy Xuat Thong Tin Sinh Vien Da Co Tren He Thong Dua Theo Ten.");
            System.out.println("3. Tim Sinh Vien Theo Yeu Cau.");
            System.out.println("0. Thoat Chuong Trinh.");
            System.out.println("+-----------------------+");
            System.out.println("Vui Long Chon So Ban Muon: ");
            LuaChon = Integer.parseInt(sc.nextLine());
            switch (LuaChon) {
                case 1: {
                    while (true) {
                        System.out.println("Truy Xuat Thong Tin Sinh Vien Theo Ma Sinh Vien: (PC08044,PC08122,PC08503,PC09014)");
                        System.out.println("Vui Long Nhap Ma So Sinh Vien Nhu Tren: ");
                        String masv = sc.nextLine();
                        if (taoMapsv.containsValue(masv)) {
                            System.out.println("Ton Tai Sinh Vien Co Ma Sinh Vien La: " + masv);
                            if (masv.equals("PC08044")) {
                                System.out.println("Ten Sinh Vien: Le Chi Thanh.");
                                System.out.println("Ma Sinh Vien: PC08044.");
                            } else if (masv.equals("PC08122")) {
                                System.out.println("Ten Sinh Vien: Nguyen Thanh Dat.");
                                System.out.println("Ma Sinh Vien: PC08122.");
                            } else if (masv.equals("PC08503")) {
                                System.out.println("Ten Sinh Vien: Nguyen Nhat Tien.");
                                System.out.println("Ma Sinh Vien: PC08503.");
                            } else if (masv.equals("PC09014")) {
                                System.out.println("Ten Sinh Vien:  Nguyen Van Vi.");
                                System.out.println("Ma Sinh Vien PC09014.");
                            } else {
                                System.out.println("Khong Tim Thay Ten Sinh Vien Nao Co Ma Sinh Vien La: " + masv);
                            }
                        } else {
                            System.out.println("Khong Tim Thay Ten Sinh Vien Nao Co Ma Sinh Ban Vua Nhap: " + masv);
                        }
                        System.out.println("Ban Co Muon Tim Sinh Vien Thong Qua Ten Khong (Yes / No ): ");
                        if (sc.nextLine().equalsIgnoreCase("No")) {
                            break;
                        }
                    }
                    break;
                }
                case 2: {
                    while (true) {
                        System.out.println("Truy Xuat Thong Tin Sinh Vien Theo Ten Sinh Vien: "
                                + "( Le Chi Thanh )"
                                + "( Nguyen Thanh Dat )"
                                + "( Nguyen Nhat Tien )"
                                + "( Nguyen Van Vi )");
                        System.out.println("Vui Long Nhap Ten So Sinh Vien Nhu Tren: ");
                        String tensv = sc.nextLine();
                        if (taoMapsv.containsValue(tensv)) {
                            System.out.println("Ton Tai Sinh Vien Co ten Sinh Vien La: " + tensv);
                            if (tensv.equals("Le Chi Thanh")) {
                                System.out.println("Ten Sinh Vien: Le Chi Thanh.");
                                System.out.println("Ma Sinh Vien: PC08044.");
                            } else if (tensv.equals("Nguyen Thanh Dat")) {
                                System.out.println("Ten Sinh Vien: Nguyen Thanh Dat.");
                                System.out.println("Ma Sinh Vien: PC08122.");
                            } else if (tensv.equals("Nguyen Nhat Tien")) {
                                System.out.println("Ten Sinh Vien: Nguyen Nhat Tien.");
                                System.out.println("Ma Sinh Vien: PC08503.");
                            } else if (tensv.equals("Nguyen Van Vi")) {
                                System.out.println("Ten Sinh Vien:  Nguyen Van Vi.");
                                System.out.println("Ma Sinh Vien PC09014.");
                            } else {
                                System.out.println("Khong Tim Thay Sinh Vien Nao Co Ten Sinh Vien La: " + tensv);
                            }
                        } else {
                            System.out.println("Khong Tim Thay Sinh Vien Nao Co Ten Sinh Ban Vua Nhap: " + tensv);
                        }
                        System.out.println("Ban Co Muon Tim Sinh Vien Thong Qua Ten Khong (Yes / No ): ");
                        if (sc.nextLine().equalsIgnoreCase("No")) {
                            break;
                        }
                    }
                    break;
                }
                case 3: {
                    while (true) {
                        System.out.println("Tim Sinh Vien (Ngoai He Thong)");
                        System.out.println("Vui Long Nhap Ten Sinh Vien Ban Muon: ");
                        String timtensv = sc.nextLine();
                        if (taoMapsv.containsValue(timtensv)) {
                            System.out.println("Sinh Vien : " + timtensv + " Nam Trong He Thong.");
                        } else {
                            System.out.println("Sinh Vien : " + timtensv + " Khong Nam Trong He Thong");
                        }
                        System.out.println("Ban Co Muon Tim Sinh Vien Thong Qua Ten Khong (Yes / No ): ");
                        if (sc.nextLine().equalsIgnoreCase("No")) {
                            break;
                        }
                    }
                    break;
                }

            }
        } while (LuaChon != 0);
    }
}
