/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package SanPham;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Scanner;

/**
 *
 * @author ADMIN
 */
public class Bai3 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        ArrayList<SanPham> spList = new ArrayList<>();
        while (true) {
            System.out.println("+--------- Menu --------+");
            System.out.println("1. Nhap Danh Sach San Pham Tu Ban Phim.");
            System.out.println("2. Sap Xep Giam Dan Theo Gia Va Xuat Ra Man Hinh.");
            System.out.println("3. Tim Va Xoa San Pham Theo Ten.");
            System.out.println("4. Xuat Gia Trung Binh Cua Cac San Pham.");
            System.out.println("0. Thoat Chuong Trinh.");
            System.out.println("+-------------------------+");
            System.out.println("Vui Long Nhap So Ma Ban Muon:  ");
            int chon = Integer.parseInt(sc.nextLine());
            if (chon == 0) {
                System.out.println("Cam On Da Su Dung Chuong Trinh Nay.");
                System.out.println("Thank You.");
                break;
            }
            switch (chon) {
                case 1:
                    System.out.println("Vui Long Nhap Ten San Pham Ban Muon: ");
                    String tensp = sc.nextLine();
                    System.out.println("Vui Long Nhap Gia San Pham Ban Muon: ");
                    double giasp = Double.parseDouble(sc.nextLine());
                    SanPham sp = new SanPham(tensp, giasp);
                    spList.add(sp);
                    for (SanPham sanPham : spList) {
                        System.out.println("Ten: " + sanPham.getTensp());
                        System.out.println("Gia: " + sanPham.getGiasp());
                    }
                    break;

                case 2:
                    Collections.sort(spList, new Comparator<SanPham>() {
                        @Override
                        public int compare(SanPham o1, SanPham o2) {
                            return Double.compare(o2.getGiasp(), o1.getGiasp()); // Sắp xếp giảm dần theo giá
                        }
                    });
                    for (SanPham sanPham : spList) {
                        System.out.println("Sản phẩm: " + sanPham.getTensp() + ", Giá: " + sanPham.getGiasp());
                        System.out.println(sanPham);
                    }
                    break;
                case 3:
                    while (true) {
                    System.out.println("Tim Du Lieu.");
                    System.out.println("Nhap Ten Muon Xoa: ");
                    String ten = sc.nextLine();
                    if (spList.contains(ten)) {
                        System.out.println("Ten Phan Tu Ban Vua Nhap Co Trong List(hovaten).");
                        while (true) {
                            System.out.println("Ban Co Muon Xoa Du Lieu Khong (Yes / No): ");
                            System.out.println("Vui Long Nhap: ");
//                                String chon = sc.nextLine();
                            if (sc.nextLine().equalsIgnoreCase("No")) {
                                break;
                            } else if (sc.nextLine().equalsIgnoreCase("Yes")) {
                                spList.remove(ten);
                                System.out.println("Da Xoa Thanh Cong");
                                break;
                            } else {
                                System.out.println("Lua chon khong hop le, vui long chon lai.");
                            }
                        }
                    } else {
                        System.out.println("Ten Ban Vua Nhap Khong Co Trong Phan Tu");
                    }
                    System.out.println("Ban Co Muon Tiep Tuc Tim Va Xoa Khong (Yes / No): ");
                    if (sc.nextLine().equalsIgnoreCase("No")) {
                        break;
                    }
                }
                break;
                case 4:
                    double tongGia = 0;
                    for (SanPham sanPham : spList) {
                        tongGia += sanPham.getGiasp();
                    }
                    double giaTrungBinh = tongGia / spList.size();
                    System.out.println("Giá trung bình của các sản phẩm: " + giaTrungBinh);
                    break;

                default:
                    System.out.println("Bạn Da Chon Sai So Roi!");
                    System.out.println("Vui Long Chon Lai So Nhe.");
            }
        }
    }
}
