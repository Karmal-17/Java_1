/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sd1901_nghiepnd_tg00418_bai5;

import com.sun.source.tree.BreakTree;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

/**
 *
 * @author ADMIN
 */
public class Menu1 {

    Scanner sc = new Scanner(System.in);
    ArrayList<String> hovaten = new ArrayList<>();

    public void Nhap() {
        while (true) {
            System.out.println("Vui Long Nhap Ten: ");
            hovaten.add(sc.nextLine());
            System.out.println("Ban Co Muon Tiep Tuc Nhap Ten Khong (Yes / No): ");
            if (sc.nextLine().equalsIgnoreCase("No")) {
                break;
            }
        }
    }

    public void Xuat() {
        System.out.println("Xuat Thong Tin.");
        for (int i = 0; i <= hovaten.size(); i++) {
            System.out.println("Phan Tu Thu " + (i + 1) + " La: " + hovaten);
        }
    }

    public void SapXep() {
        System.out.println("Sap Xep Thu Tu Phan Tu.");
        Collections.sort(hovaten);
        Collections.reverse(hovaten);
        System.out.println("Phan Tu: " + hovaten);
    }

    public void NgauNhien() {
        System.out.println("Xap Xep Ngau Nhien.");
        Collections.shuffle(hovaten);
        System.out.println("Phan Tu: " + hovaten);
    }

    public void Timvaxoa() {
        while (true) {
            System.out.println("Tim Du Lieu.");
            System.out.println("Nhap Ten Muon Xoa: ");
            String ten = sc.nextLine();
            if (hovaten.contains(ten)) {
                System.out.println("Ten Phan Tu Ban Vua Nhap Co Trong List(hovaten).");

                while (true) {
                    System.out.println("Ban Co Muon Xoa Du Lieu Khong (Yes / No): ");
                    System.out.println("Vui Long Nhap: ");
                    String chon = sc.nextLine();
                    if (chon.equalsIgnoreCase("No")) {
                        break;
                    } else if (chon.equalsIgnoreCase("Yes")) {
                        hovaten.remove(ten);
                        System.out.println("Da Xoa Thanh Cong");
                        break;
                    } else {
                        System.out.println("Lua chon khong hop le, vui long chon lai.");
                    }
                }    
            } else {
                System.out.println("Ten Ban Vua Nhap Khong Co Trong Phan Tu");
            }
            System.out.println("Ban Co Muon Tiep Tuc Tim Va Xoa Khong (Yes / No): ");
            if (sc.nextLine().equalsIgnoreCase("No")) {
                break;
            }
        }
    }

    public void ChiXoa() {
        System.out.println("Vui Long Nhap Ten Ban Muon Xoa: ");
        String tenCanXoa = sc.nextLine();
        if (hovaten.contains(tenCanXoa) == false) {
            System.out.println("Ten Khong Ton Tai Trong Danh Sach");
        } else {
            while (hovaten.contains(tenCanXoa)) {
                hovaten.remove(tenCanXoa);
            }
            System.out.println("Da Xoa Thong Cong Rui Ne.");
        }
    }
}
