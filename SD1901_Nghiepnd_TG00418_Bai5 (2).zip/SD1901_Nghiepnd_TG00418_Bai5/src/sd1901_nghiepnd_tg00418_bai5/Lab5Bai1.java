/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sd1901_nghiepnd_tg00418_bai5;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author ADMIN
 */
public class Lab5Bai1 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        ArrayList<Double> a = new ArrayList<>();
        ArrayList<Integer> b = new ArrayList<>();
        while (true) {            
            System.out.println("Vui Long Nhap So Thuc: ");
            a.add(Double.parseDouble(sc.nextLine()));
            System.out.println("Vui Long Nhap So Nguyen: ");
            b.add(Integer.parseInt(sc.nextLine()));
            System.out.println("Ban Co Muon Nhap Tiep (Y/N): ");
            if(sc.nextLine().equalsIgnoreCase("N")){
                break;
            }
            
        }
        System.out.println("Ban Da Nhap Cac So Thuc: ");
        System.out.println(a);
        System.out.println("Ban Da Nhap Cac So Nguyen: " + b);
    }
}
