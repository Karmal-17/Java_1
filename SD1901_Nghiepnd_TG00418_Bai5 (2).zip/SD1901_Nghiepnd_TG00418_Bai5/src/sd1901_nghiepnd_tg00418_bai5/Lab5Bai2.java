/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sd1901_nghiepnd_tg00418_bai5;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author ADMIN
 */
public class Lab5Bai2 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int LuaChon;
        Menu1 mn = new Menu1();
        do {            
            System.out.println("+------ Menu ---------+");
            System.out.println("1. Nhap Ho Ten.");
            System.out.println("2. Xuat Ho Ten.");
            System.out.println("3. Xuat Ngau Nhien.");
            System.out.println("4. Sap Xep.");
            System.out.println("5. Tim Du Lieu Va Xoa.");
            System.out.println("6. Xoa Du Lieu.");
            System.out.println("0. Thoat Chuong Trinh.");
            System.out.println("+-----------------------+");
            System.out.println("Vui Long Chon So Ban Muon: ");
           LuaChon = Integer.parseInt(sc.nextLine());
            switch (LuaChon) {
                case 1:
                    mn.Nhap();
                    break;
                case 2: 
                    mn.Xuat();
                    break;
                case 3: 
                    mn.NgauNhien();
                    break;
                case 4:
                    mn.SapXep();
                    break;
                case 5: 
                    mn.Timvaxoa();
                    break;
                case 6:
                    mn.ChiXoa();
                    break;
                case 0: 
                    System.out.println("Thoat Chuong Trinh.");
                    System.out.println("Cam On Da Su Dung.");
                    break;
                default:
                    System.out.println("Ban Da Chon Sai So Roi!");
                    System.out.println("Vui Long Chon Lai So Nhe.");
                    
            } 
            if(LuaChon != 0){
                System.out.println("Vui Long Nhap Vao Ban Phim Mot Ky Tu Bat Ky Tren Ban Phim De Tiep Tuc Chuong Trinh Nhe...");
                sc.nextLine();
                sc.nextLine();
            }
        } while (LuaChon != 0);
    }
}
