/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sd1901_nghiepnd_tg00418_bai5;

/**
 *
 * @author ADMIN
 */
public class HocSinh {
    private  String tenhs;
    private int tuoi;
    private double diem;

    public HocSinh() {
    }

    public HocSinh(String tenhs, int tuoi, double diem) {
        this.tenhs = tenhs;
        this.tuoi = tuoi;
        this.diem = diem;
    }

    public String getTenhs() {
        return tenhs;
    }

    public void setTenhs(String tenhs) {
        this.tenhs = tenhs;
    }

    public int getTuoi() {
        return tuoi;
    }

    public void setTuoi(int tuoi) {
        this.tuoi = tuoi;
    }

    public double getDiem() {
        return diem;
    }

    public void setDiem(double diem) {
        this.diem = diem;
    }
    
    
}
