/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sd1901_nghiepnd_tg00418_bai5;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

/**
 *
 * @author ADMIN
 */
public class Menu {

    Scanner sc = new Scanner(System.in);
    ArrayList<String> hoTenList = new ArrayList<>();

    public void Nhap() {
        while (true) {
            System.out.println("Vui Long Nhap Ho Va Ten: ");
            hoTenList.add(sc.nextLine());
            System.out.println("Ban Co Muon Tiep Tuc Khong (Y/N): ");
            if (sc.nextLine().equalsIgnoreCase("N")) {
                break;
            }
        }
    }

    public void Xuat() {
        System.out.println("Danh Sach Ho Ten: " + hoTenList);
        System.out.println("");
        for (int i = 0; i < hoTenList.size(); i++) {
            System.out.println("Phan Tu Thu " + (i + 1) + " : " + hoTenList.get(1));
        }
    }

    public void XapXepDL() {
        Collections.sort(hoTenList);
        Collections.reverse(hoTenList);
        System.out.println("Danh Sach Sau Khi Dao Nguoc: " + hoTenList);

    }

    public void NgauNhienDL() {
        Collections.shuffle(hoTenList);
        System.out.println("Danh Sach Sau Khi Xao Tron: " + hoTenList);
    }

    public void TimDL() {
        System.out.println("Vui Long Nhap Ten Ban Muon Tim: ");
        String tenCanTim = sc.nextLine();
        if (hoTenList.contains(tenCanTim)) {
            System.out.println("Tim Thay " + tenCanTim + " Trong Danh Sach.");
        } else {
            System.out.println(tenCanTim + " Khong Co Trong Danh Sach.");
        }
    }

    public void XoaDL() {
        System.out.println("Vui Long Nhap Ten Ban Muon Xoa: ");
        String tenCanXoa = sc.nextLine();
        if (hoTenList.contains(tenCanXoa) == false) {
            System.out.println("Ten Khong Ton Tai Trong Danh Sach");
        } else {
            while (hoTenList.contains(tenCanXoa)) {
                hoTenList.remove(tenCanXoa);
            }
            System.out.println("Da Xoa Thong Cong Rui Ne.");
        }
    }
}
