/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package sd1901_nghiepnd_tg00418_bai5;

import java.util.ArrayList;

/**
 *
 * @author ADMIN
 */
public class SD1901_Nghiepnd_TG00418_Bai5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        ArrayList a = new ArrayList();
        ArrayList <String> b = new ArrayList<String>();
        a.add(3);
        a.add("ABC");
        a.add(4);
        System.out.println(a);
        System.out.println(a.get(1));
        System.out.println(b);
        HocSinh hv1 = new HocSinh();
        HocSinh hv2 = new HocSinh("HS1",13,7.5);
        HocSinh hv3 = new HocSinh();
        ArrayList <HocSinh> hv = new ArrayList<HocSinh>();
        hv.add(hv1);
        hv.add(hv2);
        hv.add(hv3);
        System.out.println(hv.get(1).getTenhs());
        System.out.println(hv.get(1).getTuoi());
        System.out.println(hv.get(1).getDiem());
    }
    
}
