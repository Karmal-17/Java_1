/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sd1901_nghiepnd_tg00418_lab1;

import java.util.Scanner;

/**
 *
 * @author ADMIN
 */
public class sd1901_nghiepnd_tg00418_Bai2 {

    // Nhap Vao Hai Canh Cua Hinh Chu Nhat
    //gồm nhập chiều dài và nhập chiều rộng.
    //In ra màn hình diện tích và chu vi của HCN đó nếu đúng là HCN
    // Nếu chiều dài < chiều rộng thì không tính và in ra
    // chiều dài phải lớn hơn chiều rộng
    public static void main(String[] args) {
        double ChieuDai = 0, ChieuRong = 0;
//    double ChuVi = (ChieuDai + ChieuRong) / 2;
//    double DienTich = ChieuDai * ChieuRong;
        Scanner sc = new Scanner(System.in);
        System.out.println("Vui Long Nhap Chieu Dai: ");
        ChieuDai = sc.nextDouble();
        System.out.println("Vui Long Nhap Chieu Rong: ");
        ChieuRong = sc.nextDouble();
        if (ChieuDai < ChieuRong) {
            System.out.println("Chieu Dai Cua Ban Vua Nhap Be Hon Chieu Rong.");
        } else {
            double ChuVi = (ChieuDai + ChieuRong) / 2;
            double DienTich = ChieuDai * ChieuRong;
            System.out.println("Chu Vi Cua Hinh Chu Nhat: " + ChuVi);
            System.out.println("Dien Tich Cua Hinh Chu Nhat: " + DienTich);

        }
    }

}
