/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package sd1901_nghiepnd_tg00418_bai6;

import java.util.ArrayList;
import java.util.Arrays;

/**
 *
 * @author ADMIN
 */
public class SD1901_Nghiepnd_TG00418_Bai6 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        ArrayList<String> split = new ArrayList<>();
        String s = "  Sd1901SD1902 ";
        System.out.println("Độ dài: " + s.length());
        System.out.println("In hoa: " + s.toUpperCase());
        System.out.println("In thường " + s.toLowerCase());
        System.out.println("Cắt khoảng trắng trước sau: " + s.trim());
        System.out.println("Cắt chuỗi: " + s.substring(3,5));
        System.out.println("Lấy ký tự tại vị trí: " + s.charAt(2));
        System.out.println("Tìm và thay thế: " + s.replace("d1", "A2"));
        System.out.println("Tách thành mảng: " + Arrays.toString(s.split(s)));
        System.out.println("Vị trí xuất hiện đầu: " + s.indexOf("19"));
        System.out.println("Vị trí xuất hiện cuối: " + s.lastIndexOf("19"));
    }
    
}
