/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Try_Catch;

import java.util.Scanner;

/**
 *
 * @author ADMIN
 */
public class Menu1 {
    public static void main(String[] args) {
    int Chon;
        Scanner sc = new  Scanner(System.in);
        
        while (true){ 
            System.out.println("+------- Menu ---------+");
                System.out.println("1. Nhap So CMND ");
            System.out.println("2. Nhap So Dien Thoai.");
            System.out.println("3. Nhap So Thuc: ");
            System.out.println("0. Thoat.");
            System.out.println("+-----------------------+");
            try {
                System.out.println("Vui Long Chon So Ban Muon: ");
                Chon = Integer.valueOf(sc.nextLine());
                if(Chon == 0){
                    System.out.println("Tạm Biệt!");
                    break;
                }
                switch(Chon){
                    case 1: {
                        System.out.println("Ban Da Chon 1.");
                        System.out.println("Vui Long Nhap So CMND: ");
                        String cmnd = sc.nextLine();
                        String partenCMNN = "[0-9]{12}";
                        if(cmnd.matches(partenCMNN)){
                            System.out.println("Ban Da Nhap Dung CMND.");
                        } else {
                            System.out.println("Ban Da Nhap Sai Cau Truc.");
                        }
                        break;
                    }
                    case 2: {
                        System.out.println("Ban Da Chon 2.");
                        System.out.println("Vui long Nhap So Dien Thoai: ");
                        String sodt = sc.nextLine();
                        String partenSDT = "0[0-9]{9,10}";
                        if(sodt.matches(partenSDT)){
                            System.out.println("Ban Da Nhap Dung So.");
                        } else {
                            System.out.println("Ban Da Nhap Sai Cau Truc.");
                        }
                        break;
                    }
                    case 3: {
                        System.out.println("Ban Da Chon 3.");
                        System.out.println("Vui Long Nhap So Thuc: ");
                        String biensoxe = sc.nextLine();
                        String partenBIENSOXE = "[0-9]{2}[A-Z]{1,2}-[0-9]{5}";
                        if(biensoxe.matches(partenBIENSOXE)){
                            System.out.println("Ban Da Nhap Dung.");
                        } else {
                            System.out.println("Ban Da Nhap Sai.");
                        }
                        break;
                    }
                    default:
                        System.out.println("Ban Da Chon Sai So Roi!");
                }
            } catch (Exception e) {
                
            }
        }
        return;
    }
}
