/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Try_Catch;

import java.util.Scanner;

/**
 *
 * @author ADMIN
 */
public class Menu {
    public static void main(String[] args) {
        int Chon;
        Scanner sc = new  Scanner(System.in);
        
        while (true){ 
            System.out.println("+------- Menu ---------+");
            System.out.println("1. Nhap So Nguyen: ");
            System.out.println("2. Nhap Chuoi: ");
            System.out.println("3. Nhap So Thuc: ");
            System.out.println("0. Thoat.");
            System.out.println("+-----------------------+");
            try {
                Chon = Integer.valueOf(sc.nextLine());
                if(Chon == 0){
                    System.out.println("Tạm Biệt!");
                    break;
                }
                switch(Chon){
                    case 1: {
                        System.out.println("Ban Da Chon 1.");
                        System.out.println("Vui Long Nhap So Nguyen: ");
                        int a = Integer.valueOf(sc.nextLine());
                        break;
                    }
                    case 2: {
                        System.out.println("Ban Da Chon 2.");
                        System.out.println("Vui long Nhap Chuoi: ");
                        String c = sc.nextLine();
                        break;
                    }
                    case 3: {
                        System.out.println("Ban Da Chon 3.");
                        System.out.println("Vui Long Nhap So Thuc: ");
                        double b = Double.valueOf(sc.nextLine());
                        break;
                    }
                    default:
                        System.out.println("Ban Da Chon Sai So Roi!");
                }
            } catch (Exception e) {
                
            }
        } 
    }
}
