/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package SD1901_Nghiepnd_TG00418_Lab6;

import java.util.Scanner;

/**
 *
 * @author ADMIN
 */
public class SD1901_Nghiepnd_TG00418_Bai6 {
    public static void main(String[] args) {
//        System.out.println("Cach 1: ");
          Scanner sc = new Scanner(System.in);
//        System.out.println("Vui Long Nhap Ho Cua Ban: ");
//        String ho = sc.nextLine();
//        System.out.println("Vui Long Nhap Ten Dem Cua Ban: ");
//        String tendem = sc.nextLine();
//        System.out.println("Vui Long Nhap Ten Cua Ban: ");
//        String ten = sc.nextLine();
//        System.out.println("Ho: " + ho.trim().toUpperCase());
//        System.out.println("Ten: " + ten.trim().toUpperCase());
//        System.out.println("Ten Dem: " + tendem.trim());
        
        
        
        
//        System.out.println("Cach 2: ");
//        System.out.print("Nhập họ và tên: ");
//        String hoVaTen = sc.nextLine();
//        
//        String ho1 = hoVaTen.substring(0, hoVaTen.indexOf(" ")).toUpperCase();
//
//        String ten1 = hoVaTen.substring(hoVaTen.lastIndexOf(" ") + 1).toUpperCase();
//
//        String tenDem1 = hoVaTen.substring(hoVaTen.indexOf(" ") + 1, hoVaTen.lastIndexOf(" "));
//
//        System.out.println("Họ: " + ho);
//        System.out.println("Tên: " + ten);
//        System.out.println("Tên đệm: " + tenDem1);
//        
        
//        System.out.println("Cach 2: ");
//System.out.print("Nhập họ và tên: ");
//String hoVaTen = sc.nextLine();
//
//String ho1 = hoVaTen.substring(0, hoVaTen.indexOf(" ")).toUpperCase();
////String ten1 = hoVaTen.substring(hoVaTen.lastIndexOf(" ") + 1).toUpperCase();
////String tenDem1 = hoVaTen.substring(hoVaTen.indexOf(" ") + 1, hoVaTen.lastIndexOf(" "));
//
//String[] words = hoVaTen.split(" ");
//String ho = words[0].toUpperCase();
//String ten = words[words.length - 1].toUpperCase();
//StringBuilder tenDem = new StringBuilder();
//for (int i = 1; i < words.length - 1; i++) {
//    tenDem.append(words[i]).append(" ");
//}
//String tenDem2 = tenDem.toString().trim();
//
//System.out.println("Họ: " + ho);
//System.out.println("Tên: " + ten);
//
//for (int i = 1; i < words.length - 1; i++) {
//    System.out.println("Tên đệm: " + tenDem2);
//}

System.out.println("Cach 2: ");
System.out.print("Nhập họ và tên: ");
String hoVaTen = sc.nextLine();

//String ho1 = hoVaTen.substring(0, hoVaTen.indexOf(" ")).toUpperCase();
//String ten1 = hoVaTen.substring(hoVaTen.lastIndexOf(" ") + 1).toUpperCase();
//String tenDem1 = hoVaTen.substring(hoVaTen.indexOf(" ") + 1, hoVaTen.lastIndexOf(" "));

String[] words = hoVaTen.split(" ");
String ho = words[0].toUpperCase();
String ten = words[words.length - 1].toUpperCase();

// Lưu trữ các phần tên đệm vào mảng
String[] tenDemArray = new String[words.length - 2];
for (int i = 1; i < words.length - 1; i++) {
    tenDemArray[i - 1] = words[i];
}

// Xuất từng phần tên đệm
System.out.println("Họ: " + ho);
System.out.println("Tên: " + ten);
for (int i = 0; i < tenDemArray.length; i++) {
    System.out.println("Tên Đệm " + (i + 1) + ": " + tenDemArray[i]);
}

        return;
    }  
}
