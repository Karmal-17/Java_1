/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tuhoccodejava;

import java.util.Scanner;

/**
 *
 * @author ADMIN
 */
public class Bai2 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Vui Long Nhap So A = ");
        int a = sc.nextInt();
        System.out.println("\nVui Long Nhap So B = ");
        int b = sc.nextInt();
        while (true) {
            if (a < b) {
                System.out.println("Hien Thi Phan So Hoc");
                System.out.print("\n So Chan: ");
                for (int i = a; i <= b; i++) {
                    if (i % 2 == 0) {
                        System.out.printf("%d", i);
                    }
                }
                System.out.print("\nSo Le: ");
                for (int i = a; i <= b; i++) {
                    if (i % 2 != 0) {
                        System.out.printf("%d", i);
                    }
                }
            } else {
                System.out.print("\n So Chan: ");
                for (int i = a; i >= b; i--) {
                    if (i % 2 == 0) {
                        System.out.printf("%d ", i);
                    }
                }
                System.out.print("\n So Le: ");
                for (int i = a; i >= b; i--) {
                    if (i % 2 != 0) {
                        System.out.printf("%d", i);
                    }
                }
            }
        }
    }
}
