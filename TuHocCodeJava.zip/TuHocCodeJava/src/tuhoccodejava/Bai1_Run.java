/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tuhoccodejava;

/**
 *
 * @author ADMIN
 */
public class Bai1_Run {
    private int masinhvien;
    private String tensinhvien;
    private double diemsinhvien;

    public Bai1_Run() {
    }

    public Bai1_Run(int masinhvien, String tensinhvien, double diemsinhvien) {
        this.masinhvien = masinhvien;
        this.tensinhvien = tensinhvien;
        this.diemsinhvien = diemsinhvien;
    }

    public int getMasinhvien() {
        return masinhvien;
    }

    public void setMasinhvien(int masinhvien) {
        this.masinhvien = masinhvien;
    }

    public String getTensinhvien() {
        return tensinhvien;
    }

    public void setTensinhvien(String tensinhvien) {
        this.tensinhvien = tensinhvien;
    }

    public double getDiemsinhvien() {
        return diemsinhvien;
    }

    public void setDiemsinhvien(double diemsinhvien) {
        this.diemsinhvien = diemsinhvien;
    }
    
}

