/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tuhoccodejava;
import java.util.Scanner;
/**
 *
 * @author ADMIN
 */
public class Bai3 {



    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Vui Long Nhap So A = ");
        int a = sc.nextInt();
        System.out.print("\nVui Long Nhap So B = ");
        int b = sc.nextInt();
        
        // Thêm điều kiện dừng
        while (true) {
            if (a < b) {
                System.out.println("Hien Thi Phan So Hoc");
                System.out.print("\n So Chan: ");
                for (int i = a; i <= b; i++) {
                    if (i % 2 == 0) {
                        System.out.printf("%d ", i);
                    }
                }
                System.out.print("\n So Le: ");
                for (int i = a; i <= b; i++) {
                    if (i % 2 != 0) {
                        System.out.printf("%d ", i);
                    }
                }
            } else {
                System.out.print("\n So Chan: ");
                for (int i = a; i >= b; i--) {
                    if (i % 2 == 0) {
                        System.out.printf("%d ", i);
                    }
                }
                System.out.print("\n So Le: ");
                for (int i = a; i >= b; i--) {
                    if (i % 2 != 0) {
                        System.out.printf("%d ", i);
                    }
                }
            }
            // Thêm điều kiện thoát vòng lặp (ví dụ: hỏi người dùng tiếp tục hay không)
            System.out.print("\nBan co muon tiep tuc? (yes/no): ");
            String tiepTuc = sc.next();
            if (!tiepTuc.equalsIgnoreCase("yes")) {
                break;
            }
        }
    }
}

