/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package SD1901_Nghiepnd_TG00418_Lab6_Bai3;

import java.util.ArrayList;
import java.util.Scanner;
import sd1901_nghiepnd_tg00418_lab6.SanPham;

/**
 *
 * @author ADMIN
 */
public class Bai3 {

    public static void main(String[] args) {
        ArrayList<SinhVien> sinhVienList = new ArrayList<>();
        Scanner sc = new Scanner(System.in);
        SinhVien sv = new SinhVien();
        while (true) {
            System.out.println("+-------- Menu ---------------+");
            System.out.println("1. Nhap Thong Tin Sinh Vien.");
            System.out.println("2. Xuat Thong Tin Sinh Vien.");
            System.out.println("3. Tim Thong Tin Sinh Vien.");
            System.out.println("4. Xoa Thong Tin Sinh Vien.");
            System.out.println("0. Thoat Chuong Trinh.");
            System.out.println("+--------------------------------+");
            System.out.println("Vui Long Nhap So Ban Muon: ");
            try {
                int LuaChon = Integer.parseInt(sc.nextLine());
                if (LuaChon == 0) {
                    System.out.println("Thoat Chuong Trinh..."
                            + "Cam On Ban Da Su Dung Chuong Trinh.");
                    break;
                }
                switch (LuaChon) {
                    case 1: {
                        System.out.println("Vui Long Nhap Ten Cua Sinh Vien: ");
                        String tensv = sc.nextLine();
                        System.out.println("Vui Long Nhap Email Sinh Vien: ");
                        String email = sc.nextLine();
                        String partenEmail = "[a-z]{10}";
                        if (email.matches(partenEmail)) {
                            System.out.println("Ban Da Nhap Dung Email Cua Sinh Vien.");
                        } else {
                            System.out.println("Ban Da NHap Sai Email Cua Sin Vien Roi!");
                        }
                        System.out.println("Vui Long Nhap So Dien Thoai Sinh Vien: ");
                        String sdt = sc.nextLine();
                        String partenSDT = "0[0-9]{9}";
                        if (sdt.matches(partenSDT)) {
                            System.out.println("Ban Da Nhap Dung So Dien Thoai");
                        } else {
                            System.out.println("Ban Da Nhap Sai So Dien Thoai Roi!");
                        }
                        System.out.println("Vui Long Nhap So Chung Minh Nhan Dan.");
                        String cmnd = sc.nextLine();
                        String partenCMND = "[0-9]{14}";
                        if (cmnd.matches(partenCMND)) {
                            System.out.println("Ban Da Nhap Dung So Chung Minh Nhan Dan..");
                        } else {
                            System.out.println("Ban Da Nhap Sai So Chung Minh Nhan Dan..");
                        }
                        sinhVienList.add(sv);
                        break;
                    }
                    case 2: {
                        System.out.println("Xuat Thong Tin Sinh Vien.");
                        for (SinhVien sinhVien : sinhVienList) {
                            System.out.println(sinhVienList);
                        }
                        break;
                    }
                    case 3: {
                        System.out.println("Tim Thong tin Sinh Vien.");
                        String tenSinhVien = sc.nextLine();
                        if (sinhVienList.contains(tenSinhVien)) {
                            System.out.println("Da Tim Thay Thong Tin Sinh Vien Co Ten La: " + tenSinhVien);
                            for (SinhVien sinhVien : sinhVienList) {
                                if (sinhVienList.contains(tenSinhVien)) {
                                    System.out.println(sinhVienList);
                                }
                            }
                        } else {
                            System.out.println("Khong Tim Thay Sinh Vien Co Ten La: " + tenSinhVien);
                        }
                        break;
                    }
                    case 4: {
                        System.out.println("Xoa Thong Tin Sinh Vien. ");
                        System.out.println("Vui Long Nhap Ten Sinh Vien: ");
                        String tenSinhVien = sc.nextLine();
                        if (sinhVienList.contains(tenSinhVien)) {
                            System.out.println("Da Tim Thay Sinh Vien Co Ten La: " + tenSinhVien);
                            System.out.println("Ban Co Muon Xoa Thong Tin Sinh Vien Nay Khong"
                                    + "Vui Long Chon (Yes / No): ");
                            while (true) {
                                System.out.println("Ban Co Muon Xoa Du Lieu Khong (Yes / No): ");
                                System.out.println("Vui Long Nhap: ");
                                String chon = sc.nextLine();
                                if (chon.equalsIgnoreCase("No")) {
                                    break;
                                } else if (chon.equalsIgnoreCase("Yes")) {
                                    sinhVienList.remove(tenSinhVien);
                                    System.out.println("Da Xoa Thanh Cong");
                                    break;
                                } else {
                                    System.out.println("Lua chon khong hop le, vui long chon lai.");
                                }
                            }
                        } else {
                            System.out.println("Sinh Vien Ban Vua Nhap Khong Co Trong Danh Sach.");
                        }
                        break;
                    }
                    default:
                        System.out.println("Ban Da Chon Sai So Roi Nhe.");
                        System.out.println("Vui Long Chon Lai So Nhe.");
                }
            } catch (Exception e) {
            }
        }
    }
}
