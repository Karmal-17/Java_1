/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package SD1901_Nghiepnd_TG00418_Lab6_Bai3;

/**
 *
 * @author ADMIN
 */
public class SinhVien {
    private String tenSinhVien;
    private String emailSinhVien;
    private String sdtSinhVien;
    private String cmndSinhVien;

    public SinhVien() {
    }

    public SinhVien(String tenSinhVien, String emailSinhVien, String sdtSinhVien, String cmndSinhVien) {
        this.tenSinhVien = tenSinhVien;
        this.emailSinhVien = emailSinhVien;
        this.sdtSinhVien = sdtSinhVien;
        this.cmndSinhVien = cmndSinhVien;
    }

    public String getTenSinhVien() {
        return tenSinhVien;
    }

    public void setTenSinhVien(String tenSinhVien) {
        this.tenSinhVien = tenSinhVien;
    }

    public String getEmailSinhVien() {
        return emailSinhVien;
    }

    public void setEmailSinhVien(String emailSinhVien) {
        this.emailSinhVien = emailSinhVien;
    }

    public String getSdtSinhVien() {
        return sdtSinhVien;
    }

    public void setSdtSinhVien(String sdtSinhVien) {
        this.sdtSinhVien = sdtSinhVien;
    }

    public String getCmndSinhVien() {
        return cmndSinhVien;
    }

    public void setCmndSinhVien(String cmndSinhVien) {
        this.cmndSinhVien = cmndSinhVien;
    }
    
    
}
