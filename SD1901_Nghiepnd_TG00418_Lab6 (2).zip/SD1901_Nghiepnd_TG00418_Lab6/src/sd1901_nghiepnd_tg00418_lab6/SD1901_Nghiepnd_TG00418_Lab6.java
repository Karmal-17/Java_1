/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package sd1901_nghiepnd_tg00418_lab6;

import java.awt.BorderLayout;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author ADMIN
 */
public class SD1901_Nghiepnd_TG00418_Lab6 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner sc = new Scanner(System.in);
//        SanPham DT2 = new SanPham();
//        SanPham DT3 = new SanPham();
//        SanPham DT4 = new SanPham();
//        SanPham DT5 = new SanPham();
//        System.out.println("+---------- Phan 1 -------------+");
//        System.out.println("Nhap Thong Tin SP1.");
//        DT1.Nhapsp();
//        System.out.println("Nhap Thong Tin SP2.");
//        DT2.Nhapsp();
//        System.out.println("Nhap Thong Tin SP3.");
//        DT3.Nhapsp();
//        System.out.println("Nhap Thong Tin SP4.");
//        DT4.Nhapsp();
//        System.out.println("Nhap Thong Tin SP5.");
//        DT5.Nhapsp();
//        
//        System.out.println("+---------- Phan 2 ----------------+");
//        System.out.println("Xuat Thong Tin SP1.");
//        DT1.Xuatsp();
//        System.out.println("Xuat Thong Tin SP2.");
//        DT2.Xuatsp();
//        System.out.println("Xuat Thong Tin SP3.");
//        DT3.Xuatsp();
//        System.out.println("Xuat Thong Tin SP4.");
//        DT4.Xuatsp();
//        System.out.println("Xuat Thong Tin SP5.");
//        DT5.Xuatsp();
//        
//        System.out.println("+------------- Phap 3 ----------------+");
        ArrayList<SanPham> dienThoaiList = new ArrayList<>();
        int Chon;
        do {
            System.out.println("+------- Vui Long Chon ---------+");
            System.out.println("1. Nhap San Pham.");
            System.out.println("2. Xuat San Pham.");
            System.out.println("3. Xuat Thong Tin San Pham Co Ten Hang La: Nokia.");
            System.out.println("4. Tim Kiem Thong Tin San Pham.");
            System.out.println("5. Xoa San Pham.");
            System.out.println("0. Thoat Chuong Trinh.");
            System.out.println("+----------------------------------------------------+");
            System.out.println("Vui Long Chon So Ban Muon: ");
            Chon = Integer.parseInt(sc.nextLine());
            switch (Chon) {
                case 1: {
                    System.out.println("1. Nhap San Pham.");
                    SanPham dienthoai = new SanPham();
                    dienthoai.Nhapsp();
                    dienThoaiList.add(dienthoai);
                    break;
                }
                case 2: {
                    System.out.println("2. Xuat Thong Tin San Pham.");
                    for (SanPham sanPham : dienThoaiList) {
                        sanPham.Xuatsp();
                    }
                }
                case 3: {
                    System.out.println("Tim Thong Tin Dien Thoai Co Ten Hang La Nokia.");
                    for (int i = 0; i < dienThoaiList.size(); i++) {
                        if(dienThoaiList.contains("Nokia")){
                            System.out.println(dienThoaiList);
                        } else {
                            System.out.println("Khong Tim Thay San Pham Nao Co Ten Hang La Nokia.");
                        }
                    }
                    break;
                }
                case 4: {
                    System.out.println("4. Tim Thong Toi");
                    String tenhang = sc.nextLine();
                    if (dienThoaiList.contains(tenhang)) {
                        for (SanPham sanPham : dienThoaiList) {
                            System.out.println(dienThoaiList);
                        }
                    } else {
                        System.out.println("Khong Tim Thay San Pham Nao Co Ten Hang La: " + tenhang);
                    }
                    break;
                }
                
                case 5: {
                    while(true){
                    System.out.println("Vui Long Nhap Ten Hang: ");
                    String tenhang = sc.nextLine();
                    if (dienThoaiList.contains(tenhang)) {
                        System.out.println("Thong Tin San Pham Co Ten Hang La: " + tenhang + "Co Trong Danh Sach.");
                        while(true){
                            System.out.println("Ban Co Muon Xoa Thong Tin San Phaam Co Ten Hang La: " + tenhang + "Khong.");
                            System.out.println("Vui Long Nhap (Yes / No)");
                            if(sc.nextLine().equalsIgnoreCase("Yes")){
                                dienThoaiList.remove(tenhang);
                                break;
                            } 
                        }
                    } else {
                        System.out.println("Khong Tim Thay San Pham Nao Co Ten Hang La: " + tenhang);
                    }
                    System.out.println("Da Xoa Thanh Cong.");
                        System.out.println("Ban Co Muon Tiep Tuc Chuong Trinh Xoa San Pham Theo Ten Hang Hay Khong."
                                + "Vui Long Chon (Yes / No): ");
                        if(sc.nextLine().equalsIgnoreCase("No")){
                            break;
                        }
                    }
                }
                case 0: {
                    System.out.println("Thoat Chuong Trinh Tinh"
                            + "Cam On Ban Da Su Dung Chuong Trinh Tinh Nhe.");
                    break;
                }
                default:
                    System.out.println("Ban Da Chon Sai So Roi!"
                            + "Y La Chon Lai Di Cu.");
            }
        } while (Chon != 0);
    }

}
