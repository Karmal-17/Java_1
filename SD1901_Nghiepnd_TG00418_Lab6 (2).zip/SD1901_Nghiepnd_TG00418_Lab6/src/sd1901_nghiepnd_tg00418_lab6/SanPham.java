/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sd1901_nghiepnd_tg00418_lab6;

import java.util.Scanner;

/**
 *
 * @author ADMIN
 */
public class SanPham {
    private String tensp;
    private double giasp;
    private String hangsp;
    Scanner sc = new  Scanner(System.in);
    
    public SanPham() {
    }

    public SanPham(String tensp, double giasp, String hangsp) {
        this.tensp = tensp;
        this.giasp = giasp;
        this.hangsp = hangsp;
    }

    public String getTensp() {
        return tensp;
    }

    public void setTensp(String tensp) {
        this.tensp = tensp;
    }

    public double getGiasp() {
        return giasp;
    }

    public void setGiasp(double giasp) {
        this.giasp = giasp;
    }

    public String getHangsp() {
        return hangsp;
    }

    public void setHangsp(String hangsp) {
        this.hangsp = hangsp;
    }
    
    public void Nhapsp(){
        System.out.println("Vui Long Nhap Ten San Pham: ");
        this.tensp = sc.nextLine();
        System.out.println("Vui Long Nhap Gia Sang Pham: ");
//        this.giasp = Double.valueOf(sc.nextLine());
        this.giasp = Double.parseDouble(sc.nextLine());
        System.out.println("Vui Long Nhap Ten Hang: ");
        this.hangsp = sc.nextLine();
    }
    public void Xuatsp(){
        System.out.println("Ten San Pham: " + this.tensp);
        System.out.println("Gia San Pham: " + this.giasp);
        System.out.println("Ten Hang San Pham: " + this.hangsp);
    }
}
