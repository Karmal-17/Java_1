/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Lab7_Bai1;

/**
 *
 * @author ADMIN
 */
public class Hinh {
    public double GetChuVi(){
        return 0;
    }
    public double GetDienTich(){
        return 0;
    }
    public void Xuat(){
        
    }
}
