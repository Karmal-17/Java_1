/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Lab7_Bai1;

/**
 *
 * @author ADMIN
 */
public class Vuong extends ChuNhat {

    public Vuong() {
    }

    public Vuong(double chieuDai, double chieuRong) {
        super(chieuDai, chieuRong);
    }

//    @Override
//    public double getDienTich() {
//        return super.getDienTich(); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/OverriddenMethodBody
//    }
//
//    @Override
//    public double getChuVi() {
//        return super.getChuVi(); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/OverriddenMethodBody
//    }
//
//    @Override
//    public String toString() {
//        return super.toString(); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/OverriddenMethodBody
//    }
//
//    @Override
//    public void setChieuRong(double chieuRong) {
//        super.setChieuRong(chieuRong); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/OverriddenMethodBody
//    }
//
//    @Override
//    public double getChieuRong() {
//        return super.getChieuRong(); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/OverriddenMethodBody
//    }
//
//    @Override
//    public void setChieuDai(double chieuDai) {
//        super.setChieuDai(chieuDai); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/OverriddenMethodBody
//    }
//
//    @Override
//    public double getChieuDai() {
//        return super.getChieuDai(); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/OverriddenMethodBody
//    }
//    
//    @Override
//    public void Xuat(){
//        System.out.println("Hinh Vuong.");
//        super.Xuat();
//    }

    @Override
    public void Xuat() {
        System.out.println("Hinh Vuong.");
        super.Xuat(); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/OverriddenMethodBody
    }
    
    
}
