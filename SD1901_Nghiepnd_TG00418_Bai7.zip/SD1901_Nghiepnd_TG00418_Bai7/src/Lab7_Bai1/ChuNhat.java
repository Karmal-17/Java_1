/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Lab7_Bai1;

/**
 *
 * @author ADMIN
 */
public class ChuNhat {

    private double chieuDai;
    private double chieuRong;

    public ChuNhat() {
    }

    public ChuNhat(double chieuDai, double chieuRong) {
        this.chieuDai = chieuDai;
        this.chieuRong = chieuRong;
    }

    public double getChieuDai() {
        return chieuDai;
    }

    public void setChieuDai(double chieuDai) {
        this.chieuDai = chieuDai;
    }

    public double getChieuRong() {
        return chieuRong;
    }

    public void setChieuRong(double chieuRong) {
        this.chieuRong = chieuRong;
    }

    @Override
    public String toString() {
        return "ChuNhat{" + "chieuDai=" + chieuDai + ", chieuRong=" + chieuRong + '}';
    }

    public double getChuVi() {
        return 2 * (this.chieuDai + this.chieuRong);
    }

    public double getDienTich() {
        return this.chieuDai * this.chieuRong;
    }

    public void Xuat() {
        toString();
        System.out.println("Chu vi: " + getChuVi());
        System.out.println("Dien Tich " + getDienTich());
//        System.out.println("Hinh Chu Nhat.");
    }
}
